package com.meditrack.data.models

import com.google.gson.annotations.SerializedName
import java.util.UUID

data class PossibleCause(
    val id: String, // Using UUID string
    val cause: String,
    val description: String,
    val likelihood: String, // "High", "Medium", "Low"
    @SerializedName("urgency_level") val urgencyLevel: String // "Emergency", "Urgent", "Routine", "Self-care"
) {
    val likelihoodColor: String
        get() = when (likelihood.lowercase()) {
            "high" -> "#F44336" // Red
            "medium" -> "#FF9800" // Orange
            "low" -> "#2196F3" // Blue
            else -> "#9E9E9E" // Gray
        }
    
    val urgencyColor: String
        get() = when (urgencyLevel.lowercase()) {
            "emergency" -> "#F44336" // Red
            "urgent" -> "#FF9800" // Orange
            "routine" -> "#2196F3" // Blue
            "self-care" -> "#4CAF50" // Green
            else -> "#9E9E9E" // Gray
        }
}

data class SymptomCauseResponse(
    val message: String,
    @SerializedName("possible_causes") val possibleCauses: List<PossibleCause>,
    val disclaimer: String
)