package com.meditrack.presentation.journal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.meditrack.data.api.JournalRequest
import com.meditrack.data.models.JournalEntry
import com.meditrack.data.repository.JournalRepository
import com.meditrack.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class JournalViewModel @Inject constructor(
    private val journalRepository: JournalRepository
) : ViewModel() {

    private val _journalEntries = MutableStateFlow<List<JournalEntry>>(emptyList())
    val journalEntries: StateFlow<List<JournalEntry>> = _journalEntries.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow("")
    val errorMessage: StateFlow<String> = _errorMessage.asStateFlow()

    private val _chartData = MutableStateFlow<ChartData?>(null)
    val chartData: StateFlow<ChartData?> = _chartData.asStateFlow()

    init {
        fetchJournalEntries()
    }

    fun fetchJournalEntries() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = ""

            when (val result = journalRepository.getJournalEntries()) {
                is Resource.Success -> {
                    _journalEntries.value = result.data.sortedByDescending { it.dateExperienced }
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message ?: "Failed to load journal entries"
                }
            }

            _isLoading.value = false
        }
    }

    fun fetchChartData() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = ""

            when (val result = journalRepository.getJournalChartData()) {
                is Resource.Success -> {
                    _chartData.value = result.data
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message ?: "Failed to load chart data"
                }
            }

            _isLoading.value = false
        }
    }

    fun addJournalEntry(symptom: String, description: String?, severity: Int, date: Date) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = ""

            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val dateString = dateFormat.format(date)

            val request = JournalRequest(
                symptom = symptom,
                description = description,
                severity = severity,
                date_experienced = dateString
            )

            when (val result = journalRepository.addJournalEntry(request)) {
                is Resource.Success -> {
                    // Add the new entry to the local list
                    val newEntries = _journalEntries.value.toMutableList()
                    newEntries.add(0, result.data.entry)
                    _journalEntries.value = newEntries
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message ?: "Failed to add journal entry"
                }
            }

            _isLoading.value = false
        }
    }

    fun deleteJournalEntry(id: Int) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = ""

            when (val result = journalRepository.deleteJournalEntry(id)) {
                is Resource.Success -> {
                    // Remove the deleted entry from the local list
                    _journalEntries.value = _journalEntries.value.filter { it.id != id }
                }
                is Resource.Error -> {
                    _errorMessage.value = result.message ?: "Failed to delete journal entry"
                }
            }

            _isLoading.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = ""
    }
}

data class ChartData(
    val labels: List<String>,
    val datasets: List<ChartDataset>
)

data class ChartDataset(
    val label: String,
    val data: List<Int>,
    val backgroundColor: String,
    val borderColor: String,
    val borderWidth: Int,
    val fill: Boolean,
    val tension: Double,
    val dates: List<String>
)