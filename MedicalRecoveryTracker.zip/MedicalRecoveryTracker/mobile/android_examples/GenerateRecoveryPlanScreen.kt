package com.meditrack.presentation.recoveryplan

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.meditrack.data.models.Activity
import com.meditrack.data.models.JournalEntry
import com.meditrack.data.models.RecoveryPlanDetail
import com.meditrack.data.models.Recommendation
import com.meditrack.presentation.components.EmptyStateView
import com.meditrack.presentation.components.LoadingView
import kotlinx.coroutines.launch

enum class PlanType(val title: String, val description: String, val icon: ImageVector, val color: Color) {
    GENERAL(
        "General Recovery",
        "A comprehensive plan to address your symptoms with lifestyle recommendations and general recovery advice.",
        Icons.Default.Favorite,
        Color(0xFF2196F3) // Blue
    ),
    NUTRITION(
        "Nutrition",
        "Dietary guidance tailored to alleviate your symptoms and support recovery with nutritional recommendations.",
        Icons.Default.Restaurant,
        Color(0xFF4CAF50) // Green
    ),
    SPORTS(
        "Sports Recovery",
        "Sports-specific recovery strategies for athletes, incorporating your activity profile and symptom patterns.",
        Icons.Default.SportsSoccer,
        Color(0xFFFF9800) // Orange
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenerateRecoveryPlanScreen(
    navigateToPlanDetails: (Int) -> Unit,
    viewModel: RecoveryPlanViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val journalEntries by viewModel.journalEntries.collectAsState()
    val activities by viewModel.activities.collectAsState()
    val selectedSymptomIds by viewModel.selectedSymptomIds.collectAsState()
    val selectedActivityIds by viewModel.selectedActivityIds.collectAsState()
    
    var selectedPlanType by remember { mutableStateOf(PlanType.GENERAL) }
    var showGeneratedPlanDialog by remember { mutableStateOf(false) }
    var generatedPlan by remember { mutableStateOf<RecoveryPlanDetail?>(null) }
    
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    
    LaunchedEffect(state) {
        when (state) {
            is RecoveryPlanState.Error -> {
                scope.launch {
                    snackbarHostState.showSnackbar((state as RecoveryPlanState.Error).message)
                    viewModel.clearState()
                }
            }
            is RecoveryPlanState.PlanGenerated -> {
                generatedPlan = (state as RecoveryPlanState.PlanGenerated).plan
                showGeneratedPlanDialog = true
                viewModel.clearState()
            }
            else -> { /* Do nothing */ }
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Recovery Plan") }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Plan Type Selection
                item {
                    PlanTypeSelection(
                        selectedPlanType = selectedPlanType,
                        onPlanTypeSelected = { selectedPlanType = it }
                    )
                }
                
                // Symptom Selection
                item {
                    SymptomSelection(
                        journalEntries = journalEntries,
                        selectedIds = selectedSymptomIds,
                        onToggleSelection = { viewModel.toggleSymptomSelection(it) }
                    )
                }
                
                // Activity Selection (only for Sports plan)
                if (selectedPlanType == PlanType.SPORTS) {
                    item {
                        ActivitySelection(
                            activities = activities,
                            selectedIds = selectedActivityIds,
                            onToggleSelection = { viewModel.toggleActivitySelection(it) }
                        )
                    }
                }
                
                // Generate Button
                item {
                    GenerateButton(
                        planType = selectedPlanType,
                        enabled = if (selectedPlanType == PlanType.SPORTS) {
                            selectedSymptomIds.isNotEmpty() && selectedActivityIds.isNotEmpty()
                        } else {
                            selectedSymptomIds.isNotEmpty()
                        },
                        onClick = {
                            when (selectedPlanType) {
                                PlanType.GENERAL -> viewModel.generateGeneralPlan()
                                PlanType.NUTRITION -> viewModel.generateNutritionPlan()
                                PlanType.SPORTS -> viewModel.generateSportsPlan()
                            }
                        }
                    )
                }
            }
            
            if (state is RecoveryPlanState.Loading) {
                LoadingDialog()
            }
            
            if (showGeneratedPlanDialog && generatedPlan != null) {
                PlanGeneratedDialog(
                    plan = generatedPlan!!,
                    onDismiss = { showGeneratedPlanDialog = false },
                    onViewDetails = {
                        navigateToPlanDetails(generatedPlan!!.id)
                        showGeneratedPlanDialog = false
                    }
                )
            }
        }
    }
}

@Composable
fun PlanTypeSelection(
    selectedPlanType: PlanType,
    onPlanTypeSelected: (PlanType) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Select Plan Type",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        
        PlanType.values().forEach { planType ->
            PlanTypeCard(
                planType = planType,
                isSelected = planType == selectedPlanType,
                onClick = { onPlanTypeSelected(planType) }
            )
        }
    }
}

@Composable
fun PlanTypeCard(
    planType: PlanType,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) planType.color.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 2.dp,
            color = if (isSelected) planType.color else Color.Gray.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = planType.color.copy(alpha = 0.1f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = planType.icon,
                    contentDescription = null,
                    tint = planType.color,
                    modifier = Modifier.size(24.dp)
                )
            }
            
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = planType.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = planType.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = planType.color
                )
            }
        }
    }
}

@Composable
fun SymptomSelection(
    journalEntries: List<JournalEntry>,
    selectedIds: Set<Int>,
    onToggleSelection: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Select Symptoms",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = "${selectedIds.size} selected",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        if (journalEntries.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.MedicalServices,
                title = "No Symptoms Recorded",
                message = "You need to record symptoms in your journal before generating a recovery plan."
            )
        } else {
            journalEntries.forEach { entry ->
                SymptomItem(
                    journalEntry = entry,
                    isSelected = selectedIds.contains(entry.id),
                    onToggleSelection = { onToggleSelection(entry.id) }
                )
            }
        }
    }
}

@Composable
fun SymptomItem(
    journalEntry: JournalEntry,
    isSelected: Boolean,
    onToggleSelection: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleSelection() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) 
            else 
                MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = Color.Gray.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = journalEntry.symptom,
                    style = MaterialTheme.typography.titleMedium
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Severity: ${journalEntry.severity}/10",
                        style = MaterialTheme.typography.bodySmall
                    )
                    
                    Text(
                        text = journalEntry.formattedDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelection() }
            )
        }
    }
}

@Composable
fun ActivitySelection(
    activities: List<Activity>,
    selectedIds: Set<Int>,
    onToggleSelection: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Select Activities",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = "${selectedIds.size} selected",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        if (activities.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.DirectionsRun,
                title = "No Activities Recorded",
                message = "You need to add your regular athletic activities in your profile before generating a sports recovery plan."
            )
        } else {
            activities.forEach { activity ->
                ActivityItem(
                    activity = activity,
                    isSelected = selectedIds.contains(activity.id),
                    onToggleSelection = { onToggleSelection(activity.id) }
                )
            }
        }
    }
}

@Composable
fun ActivityItem(
    activity: Activity,
    isSelected: Boolean,
    onToggleSelection: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleSelection() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) 
                Color(0xFFFF9800).copy(alpha = 0.1f) 
            else 
                MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = Color.Gray.copy(alpha = 0.3f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = activity.name,
                    style = MaterialTheme.typography.titleMedium
                )
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Intensity: ${activity.intensity.capitalize()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    
                    activity.frequency?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelection() }
            )
        }
    }
}

@Composable
fun GenerateButton(
    planType: PlanType,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = planType.color,
            disabledContainerColor = Color.Gray
        )
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null
            )
            
            Text(
                text = "Generate ${planType.title}",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
fun LoadingDialog() {
    Dialog(
        onDismissRequest = { /* Cannot dismiss while loading */ }
    ) {
        Box(
            modifier = Modifier
                .background(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(48.dp)
                )
                
                Text(
                    text = "Generating your personalized plan...",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = "Our AI is analyzing your symptoms and creating recommendations.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun PlanGeneratedDialog(
    plan: RecoveryPlanDetail,
    onDismiss: () -> Unit,
    onViewDetails: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color.Green,
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.CenterHorizontally)
                )
                
                Text(
                    text = "Recovery Plan Generated",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Text(
                    text = plan.title,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                if (plan.description != null) {
                    Text(
                        text = plan.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                
                Text(
                    text = "${plan.recommendations.size} recommendations generated",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Close")
                    }
                    
                    Button(
                        onClick = onViewDetails,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("View Details")
                    }
                }
            }
        }
    }
}

// Helper extension function to handle Strings
private fun String.capitalize(): String {
    return this.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}