package com.meditrack.presentation.recoveryplan

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.meditrack.data.api.SportsPlanRequest
import com.meditrack.data.api.SymptomIdsRequest
import com.meditrack.data.models.Activity
import com.meditrack.data.models.JournalEntry
import com.meditrack.data.models.RecoveryPlan
import com.meditrack.data.models.RecoveryPlanDetail
import com.meditrack.data.repository.ActivityRepository
import com.meditrack.data.repository.JournalRepository
import com.meditrack.data.repository.RecoveryPlanRepository
import com.meditrack.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RecoveryPlanViewModel @Inject constructor(
    private val recoveryPlanRepository: RecoveryPlanRepository,
    private val journalRepository: JournalRepository,
    private val activityRepository: ActivityRepository
) : ViewModel() {

    private val _recoveryPlans = MutableStateFlow<List<RecoveryPlan>>(emptyList())
    val recoveryPlans: StateFlow<List<RecoveryPlan>> = _recoveryPlans.asStateFlow()

    private val _selectedPlanDetails = MutableStateFlow<RecoveryPlanDetail?>(null)
    val selectedPlanDetails: StateFlow<RecoveryPlanDetail?> = _selectedPlanDetails.asStateFlow()

    private val _journalEntries = MutableStateFlow<List<JournalEntry>>(emptyList())
    val journalEntries: StateFlow<List<JournalEntry>> = _journalEntries.asStateFlow()

    private val _activities = MutableStateFlow<List<Activity>>(emptyList())
    val activities: StateFlow<List<Activity>> = _activities.asStateFlow()

    private val _selectedSymptomIds = MutableStateFlow<Set<Int>>(emptySet())
    val selectedSymptomIds: StateFlow<Set<Int>> = _selectedSymptomIds.asStateFlow()

    private val _selectedActivityIds = MutableStateFlow<Set<Int>>(emptySet())
    val selectedActivityIds: StateFlow<Set<Int>> = _selectedActivityIds.asStateFlow()

    private val _state = MutableStateFlow<RecoveryPlanState>(RecoveryPlanState.Initial)
    val state: StateFlow<RecoveryPlanState> = _state.asStateFlow()

    init {
        fetchRecoveryPlans()
        fetchJournalEntries()
        fetchActivities()
    }

    fun fetchRecoveryPlans(type: String? = null) {
        viewModelScope.launch {
            _state.value = RecoveryPlanState.Loading

            when (val result = recoveryPlanRepository.getRecoveryPlans(type)) {
                is Resource.Success -> {
                    _recoveryPlans.value = result.data.sortedByDescending { it.createdAt }
                    _state.value = RecoveryPlanState.Success
                }
                is Resource.Error -> {
                    _state.value = RecoveryPlanState.Error(result.message ?: "Failed to load recovery plans")
                }
            }
        }
    }

    fun fetchPlanDetails(id: Int) {
        viewModelScope.launch {
            _state.value = RecoveryPlanState.Loading

            when (val result = recoveryPlanRepository.getRecoveryPlanDetails(id)) {
                is Resource.Success -> {
                    _selectedPlanDetails.value = result.data
                    _state.value = RecoveryPlanState.Success
                }
                is Resource.Error -> {
                    _state.value = RecoveryPlanState.Error(result.message ?: "Failed to load plan details")
                }
            }
        }
    }

    private fun fetchJournalEntries() {
        viewModelScope.launch {
            when (val result = journalRepository.getJournalEntries()) {
                is Resource.Success -> {
                    _journalEntries.value = result.data
                }
                is Resource.Error -> {
                    // We don't set the error state here to avoid overriding the main state
                    // Just log it or handle it separately
                }
            }
        }
    }

    private fun fetchActivities() {
        viewModelScope.launch {
            when (val result = activityRepository.getActivities()) {
                is Resource.Success -> {
                    _activities.value = result.data
                }
                is Resource.Error -> {
                    // We don't set the error state here to avoid overriding the main state
                    // Just log it or handle it separately
                }
            }
        }
    }

    fun toggleSymptomSelection(id: Int) {
        val currentSelection = _selectedSymptomIds.value.toMutableSet()
        if (currentSelection.contains(id)) {
            currentSelection.remove(id)
        } else {
            currentSelection.add(id)
        }
        _selectedSymptomIds.value = currentSelection
    }

    fun toggleActivitySelection(id: Int) {
        val currentSelection = _selectedActivityIds.value.toMutableSet()
        if (currentSelection.contains(id)) {
            currentSelection.remove(id)
        } else {
            currentSelection.add(id)
        }
        _selectedActivityIds.value = currentSelection
    }

    fun generateGeneralPlan() {
        val symptomIds = _selectedSymptomIds.value.toList()
        
        if (symptomIds.isEmpty()) {
            _state.value = RecoveryPlanState.Error("Please select at least one symptom")
            return
        }
        
        viewModelScope.launch {
            _state.value = RecoveryPlanState.Loading

            when (val result = recoveryPlanRepository.generateGeneralPlan(SymptomIdsRequest(symptomIds))) {
                is Resource.Success -> {
                    _selectedPlanDetails.value = result.data.plan
                    fetchRecoveryPlans() // Refresh the list
                    clearSelections()
                    _state.value = RecoveryPlanState.PlanGenerated(result.data.plan)
                }
                is Resource.Error -> {
                    _state.value = RecoveryPlanState.Error(result.message ?: "Failed to generate plan")
                }
            }
        }
    }

    fun generateNutritionPlan() {
        val symptomIds = _selectedSymptomIds.value.toList()
        
        if (symptomIds.isEmpty()) {
            _state.value = RecoveryPlanState.Error("Please select at least one symptom")
            return
        }
        
        viewModelScope.launch {
            _state.value = RecoveryPlanState.Loading

            when (val result = recoveryPlanRepository.generateNutritionPlan(SymptomIdsRequest(symptomIds))) {
                is Resource.Success -> {
                    _selectedPlanDetails.value = result.data.plan
                    fetchRecoveryPlans() // Refresh the list
                    clearSelections()
                    _state.value = RecoveryPlanState.PlanGenerated(result.data.plan)
                }
                is Resource.Error -> {
                    _state.value = RecoveryPlanState.Error(result.message ?: "Failed to generate plan")
                }
            }
        }
    }

    fun generateSportsPlan() {
        val symptomIds = _selectedSymptomIds.value.toList()
        val activityIds = _selectedActivityIds.value.toList()
        
        if (symptomIds.isEmpty()) {
            _state.value = RecoveryPlanState.Error("Please select at least one symptom")
            return
        }
        
        if (activityIds.isEmpty()) {
            _state.value = RecoveryPlanState.Error("Please select at least one activity")
            return
        }
        
        viewModelScope.launch {
            _state.value = RecoveryPlanState.Loading

            when (val result = recoveryPlanRepository.generateSportsPlan(SportsPlanRequest(symptomIds, activityIds))) {
                is Resource.Success -> {
                    _selectedPlanDetails.value = result.data.plan
                    fetchRecoveryPlans() // Refresh the list
                    clearSelections()
                    _state.value = RecoveryPlanState.PlanGenerated(result.data.plan)
                }
                is Resource.Error -> {
                    _state.value = RecoveryPlanState.Error(result.message ?: "Failed to generate plan")
                }
            }
        }
    }
    
    private fun clearSelections() {
        _selectedSymptomIds.value = emptySet()
        _selectedActivityIds.value = emptySet()
    }
    
    fun clearState() {
        _state.value = RecoveryPlanState.Initial
    }
}

sealed class RecoveryPlanState {
    object Initial : RecoveryPlanState()
    object Loading : RecoveryPlanState()
    object Success : RecoveryPlanState()
    data class Error(val message: String) : RecoveryPlanState()
    data class PlanGenerated(val plan: RecoveryPlanDetail) : RecoveryPlanState()
}