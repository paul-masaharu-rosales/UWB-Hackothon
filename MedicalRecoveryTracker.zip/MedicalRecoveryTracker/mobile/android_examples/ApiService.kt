package com.meditrack.data.api

import com.meditrack.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    // Authentication
    @POST("auth/login")
    suspend fun login(@Body loginRequest: LoginRequest): Response<LoginResponse>

    @POST("auth/register")
    suspend fun register(@Body registerRequest: RegisterRequest): Response<RegisterResponse>

    @POST("auth/logout")
    suspend fun logout(): Response<MessageResponse>

    // User Profile
    @GET("user/profile")
    suspend fun getUserProfile(): Response<User>

    @PUT("user/profile")
    suspend fun updateUserProfile(@Body profileRequest: ProfileRequest): Response<ProfileResponse>

    // Journal Entries
    @GET("journal")
    suspend fun getJournalEntries(): Response<List<JournalEntry>>

    @POST("journal")
    suspend fun addJournalEntry(@Body journalRequest: JournalRequest): Response<JournalEntryResponse>

    @DELETE("journal/{id}")
    suspend fun deleteJournalEntry(@Path("id") id: Int): Response<MessageResponse>

    @GET("journal/chart-data")
    suspend fun getJournalChartData(): Response<ChartData>

    // Recovery Plans
    @GET("recovery-plans")
    suspend fun getRecoveryPlans(@Query("type") type: String? = null): Response<List<RecoveryPlan>>

    @GET("recovery-plans/{id}")
    suspend fun getRecoveryPlanDetails(@Path("id") id: Int): Response<RecoveryPlanDetail>

    @POST("recovery-plans/general")
    suspend fun generateGeneralPlan(@Body request: SymptomIdsRequest): Response<RecoveryPlanResponse>

    @POST("recovery-plans/nutrition")
    suspend fun generateNutritionPlan(@Body request: SymptomIdsRequest): Response<RecoveryPlanResponse>

    @POST("recovery-plans/sports")
    suspend fun generateSportsPlan(@Body request: SportsPlanRequest): Response<RecoveryPlanResponse>

    // Activities
    @GET("activities")
    suspend fun getActivities(): Response<List<Activity>>

    @POST("activities")
    suspend fun addActivity(@Body activityRequest: ActivityRequest): Response<ActivityResponse>

    @DELETE("activities/{id}")
    suspend fun deleteActivity(@Path("id") id: Int): Response<MessageResponse>

    // Allergies
    @GET("allergies")
    suspend fun getAllergies(): Response<List<Allergy>>

    @POST("allergies")
    suspend fun addAllergy(@Body allergyRequest: AllergyRequest): Response<AllergyResponse>

    @DELETE("allergies/{id}")
    suspend fun deleteAllergy(@Path("id") id: Int): Response<MessageResponse>
    
    // Symptom Analysis
    @POST("symptom-analysis/causes")
    suspend fun analyzePossibleCauses(@Body request: SymptomAnalysisRequest): Response<SymptomCauseResponse>
}

// Request/Response classes
data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val message: String,
    val user: User
)

data class RegisterRequest(
    val email: String,
    val password: String,
    val first_name: String? = null,
    val last_name: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val weight: Double? = null,
    val height: Double? = null
)

data class RegisterResponse(
    val message: String,
    val user_id: Int
)

data class MessageResponse(
    val message: String
)

data class ProfileRequest(
    val first_name: String? = null,
    val last_name: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val weight: Double? = null,
    val height: Double? = null
)

data class ProfileResponse(
    val message: String,
    val user: User
)

data class JournalRequest(
    val symptom: String,
    val description: String? = null,
    val severity: Int,
    val date_experienced: String
)

data class ActivityRequest(
    val name: String,
    val frequency: String? = null,
    val intensity: String,
    val notes: String? = null
)

data class AllergyRequest(
    val food_item: String,
    val severity: String,
    val notes: String? = null
)

data class SymptomIdsRequest(
    val symptom_ids: List<Int>
)

data class SportsPlanRequest(
    val symptom_ids: List<Int>,
    val activity_ids: List<Int>
)

data class SymptomAnalysisRequest(
    val symptom_description: String
)