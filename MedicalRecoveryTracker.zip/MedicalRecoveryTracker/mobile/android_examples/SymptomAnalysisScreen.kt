package com.meditrack.presentation.symptomanalysis

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import com.meditrack.data.models.PossibleCause
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SymptomAnalysisScreen(
    viewModel: SymptomAnalysisViewModel = hiltViewModel()
) {
    val symptomDescription by viewModel.symptomDescription.collectAsState()
    val possibleCauses by viewModel.possibleCauses.collectAsState()
    val disclaimer by viewModel.disclaimer.collectAsState()
    val state by viewModel.state.collectAsState()
    
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    
    var showMedicalDisclaimer by remember { mutableStateOf(true) }
    
    LaunchedEffect(state) {
        when (state) {
            is SymptomAnalysisState.Error -> {
                scope.launch {
                    snackbarHostState.showSnackbar((state as SymptomAnalysisState.Error).message)
                    viewModel.clearState()
                }
            }
            is SymptomAnalysisState.Success -> {
                // Auto-scroll to results when they arrive
                scrollState.animateScrollTo(scrollState.maxValue)
                viewModel.clearState()
            }
            else -> { /* Do nothing */ }
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Symptom Analysis") }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Header
                SymptomAnalysisHeader()
                
                // Input
                SymptomInputSection(
                    value = symptomDescription,
                    onValueChange = { viewModel.updateSymptomDescription(it) },
                    isLoading = state is SymptomAnalysisState.Loading
                )
                
                // Analyze Button
                AnalyzeButton(
                    enabled = symptomDescription.isNotBlank() && state !is SymptomAnalysisState.Loading,
                    isLoading = state is SymptomAnalysisState.Loading,
                    onClick = { viewModel.analyzePossibleCauses() }
                )
                
                // Results Section
                if (possibleCauses.isNotEmpty()) {
                    ResultsSection(
                        possibleCauses = possibleCauses,
                        disclaimer = disclaimer
                    )
                }
            }
            
            if (showMedicalDisclaimer) {
                MedicalDisclaimerDialog(
                    onDismiss = { showMedicalDisclaimer = false }
                )
            }
        }
    }
}

@Composable
fun SymptomAnalysisHeader() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Symptom Analysis",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = "Describe your symptoms in detail to get AI-generated possible causes and recommendations.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun SymptomInputSection(
    value: String,
    onValueChange: (String) -> Unit,
    isLoading: Boolean
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Describe Your Symptoms",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        
        Box {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 150.dp),
                enabled = !isLoading,
                placeholder = {
                    Text(
                        "Example: I've had a persistent headache behind my right eye for 3 days, along with some nausea in the morning. The pain is worse when I bend over."
                    )
                },
                shape = RoundedCornerShape(8.dp)
            )
        }
    }
}

@Composable
fun AnalyzeButton(
    enabled: Boolean,
    isLoading: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = Icons.Default.HealthAndSafety,
                    contentDescription = null
                )
            }
            
            Text(
                text = if (isLoading) "Analyzing..." else "Analyze Symptoms",
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
fun ResultsSection(
    possibleCauses: List<PossibleCause>,
    disclaimer: String
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Possible Causes",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        
        DisclaimerBox(disclaimer)
        
        possibleCauses.forEach { cause ->
            CauseCard(cause = cause)
        }
    }
}

@Composable
fun DisclaimerBox(disclaimer: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFFFEEAEA),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color.Red
                )
                
                Text(
                    text = "Medical Disclaimer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Red
                )
            }
            
            Text(
                text = disclaimer.ifEmpty {
                    "This information is generated by AI and should not be used as a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun CauseCard(cause: PossibleCause) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = cause.cause,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (expanded) "Show less" else "Show more"
                    )
                }
            }
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LikelihoodTag(likelihood = cause.likelihood)
                UrgencyTag(urgency = cause.urgencyLevel)
            }
            
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Text(
                    text = cause.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
fun LikelihoodTag(likelihood: String) {
    val color = when (likelihood.lowercase()) {
        "high" -> Color(0xFFF44336) // Red
        "medium" -> Color(0xFFFF9800) // Orange
        "low" -> Color(0xFF2196F3) // Blue
        else -> Color(0xFF9E9E9E) // Gray
    }
    
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.1f)
    ) {
        Text(
            text = "Likelihood: $likelihood",
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun UrgencyTag(urgency: String) {
    val color = when (urgency.lowercase()) {
        "emergency" -> Color(0xFFF44336) // Red
        "urgent" -> Color(0xFFFF9800) // Orange
        "routine" -> Color(0xFF2196F3) // Blue
        "self-care" -> Color(0xFF4CAF50) // Green
        else -> Color(0xFF9E9E9E) // Gray
    }
    
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = color.copy(alpha = 0.1f)
    ) {
        Text(
            text = urgency,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun MedicalDisclaimerDialog(
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = { /* Prevent dismissal by tapping outside */ }
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = Color(0xFFFF9800),
                    modifier = Modifier.size(48.dp)
                )
                
                Text(
                    text = "Important Medical Disclaimer",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    DisclaimerItem(
                        title = "Not Medical Advice",
                        content = "The information provided by this app is not intended to be a substitute for professional medical advice, diagnosis, or treatment."
                    )
                    
                    DisclaimerItem(
                        title = "AI-Generated Content",
                        content = "This analysis is generated by artificial intelligence based on the symptoms you provide. AI has limitations and may not capture the full context of your health situation."
                    )
                    
                    DisclaimerItem(
                        title = "Seek Medical Help",
                        content = "Always consult with a qualified healthcare provider for proper diagnosis and treatment. If you're experiencing a medical emergency, call emergency services immediately."
                    )
                    
                    DisclaimerItem(
                        title = "Privacy",
                        content = "Your symptom information is processed to generate these analyses. Please refer to our privacy policy for details on how your health information is handled."
                    )
                }
                
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("I Understand")
                }
            }
        }
    }
}

@Composable
fun DisclaimerItem(
    title: String,
    content: String
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = content,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}