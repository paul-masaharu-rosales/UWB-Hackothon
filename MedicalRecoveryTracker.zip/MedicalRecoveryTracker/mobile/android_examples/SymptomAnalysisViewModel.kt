package com.meditrack.presentation.symptomanalysis

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.meditrack.data.api.SymptomAnalysisRequest
import com.meditrack.data.models.PossibleCause
import com.meditrack.data.repository.SymptomAnalysisRepository
import com.meditrack.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SymptomAnalysisViewModel @Inject constructor(
    private val repository: SymptomAnalysisRepository
) : ViewModel() {

    private val _symptomDescription = MutableStateFlow("")
    val symptomDescription: StateFlow<String> = _symptomDescription.asStateFlow()

    private val _possibleCauses = MutableStateFlow<List<PossibleCause>>(emptyList())
    val possibleCauses: StateFlow<List<PossibleCause>> = _possibleCauses.asStateFlow()

    private val _disclaimer = MutableStateFlow("")
    val disclaimer: StateFlow<String> = _disclaimer.asStateFlow()

    private val _state = MutableStateFlow<SymptomAnalysisState>(SymptomAnalysisState.Initial)
    val state: StateFlow<SymptomAnalysisState> = _state.asStateFlow()

    fun updateSymptomDescription(description: String) {
        _symptomDescription.value = description
    }

    fun analyzePossibleCauses() {
        val description = _symptomDescription.value
        
        if (description.isBlank()) {
            _state.value = SymptomAnalysisState.Error("Please enter a symptom description")
            return
        }
        
        viewModelScope.launch {
            _state.value = SymptomAnalysisState.Loading
            
            when (val result = repository.analyzePossibleCauses(SymptomAnalysisRequest(description))) {
                is Resource.Success -> {
                    _possibleCauses.value = result.data.possibleCauses
                    _disclaimer.value = result.data.disclaimer
                    _state.value = SymptomAnalysisState.Success
                }
                is Resource.Error -> {
                    _state.value = SymptomAnalysisState.Error(result.message ?: "Failed to analyze symptoms")
                }
            }
        }
    }
    
    fun clearState() {
        _state.value = SymptomAnalysisState.Initial
    }
}

sealed class SymptomAnalysisState {
    object Initial : SymptomAnalysisState()
    object Loading : SymptomAnalysisState()
    object Success : SymptomAnalysisState()
    data class Error(val message: String) : SymptomAnalysisState()
}