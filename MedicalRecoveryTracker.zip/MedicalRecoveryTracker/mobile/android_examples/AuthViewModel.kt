package com.meditrack.presentation.authentication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.meditrack.data.api.LoginRequest
import com.meditrack.data.api.RegisterRequest
import com.meditrack.data.models.User
import com.meditrack.data.repository.AuthRepository
import com.meditrack.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _user = MutableStateFlow<User?>(null)
    val user: StateFlow<User?> = _user.asStateFlow()

    init {
        // Check if the user is already authenticated
        checkAuthentication()
    }

    private fun checkAuthentication() {
        viewModelScope.launch {
            val user = authRepository.getCurrentUser()
            if (user != null) {
                _user.value = user
                _isAuthenticated.value = true
            }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading

            when (val result = authRepository.login(LoginRequest(email, password))) {
                is Resource.Success -> {
                    _user.value = result.data.user
                    _isAuthenticated.value = true
                    _authState.value = AuthState.Success
                }
                is Resource.Error -> {
                    _authState.value = AuthState.Error(result.message ?: "Unknown error occurred")
                }
            }
        }
    }

    fun register(
        email: String,
        password: String,
        firstName: String? = null,
        lastName: String? = null,
        age: Int? = null,
        gender: String? = null,
        weight: Double? = null,
        height: Double? = null
    ) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading

            val request = RegisterRequest(
                email = email,
                password = password,
                first_name = firstName,
                last_name = lastName,
                age = age,
                gender = gender,
                weight = weight,
                height = height
            )

            when (val result = authRepository.register(request)) {
                is Resource.Success -> {
                    // After successful registration, automatically log in
                    login(email, password)
                }
                is Resource.Error -> {
                    _authState.value = AuthState.Error(result.message ?: "Unknown error occurred")
                }
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _authState.value = AuthState.Loading

            when (val result = authRepository.logout()) {
                is Resource.Success -> {
                    clearUserData()
                    _authState.value = AuthState.Initial
                }
                is Resource.Error -> {
                    // Even if the server logout fails, clear local data
                    clearUserData()
                    _authState.value = AuthState.Initial
                }
            }
        }
    }

    private fun clearUserData() {
        _user.value = null
        _isAuthenticated.value = false
        authRepository.clearUserData()
    }

    fun resetAuthState() {
        _authState.value = AuthState.Initial
    }
}

sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}