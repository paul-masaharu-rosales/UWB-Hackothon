package com.meditrack.data.models

import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.Locale

data class User(
    val id: Int,
    val email: String,
    @SerializedName("first_name") val firstName: String?,
    @SerializedName("last_name") val lastName: String?,
    val age: Int?,
    val gender: String?,
    val weight: Double?,
    val height: Double?,
    val bmi: Double?
) {
    val fullName: String
        get() = when {
            firstName != null && lastName != null -> "$firstName $lastName"
            firstName != null -> firstName
            lastName != null -> lastName
            else -> email
        }
}

data class JournalEntry(
    val id: Int,
    val symptom: String,
    val description: String?,
    val severity: Int,
    @SerializedName("date_experienced") val dateExperienced: String,
    @SerializedName("created_at") val createdAt: String
) {
    val formattedDate: String
        get() {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
            return try {
                val date = inputFormat.parse(dateExperienced)
                date?.let { outputFormat.format(it) } ?: dateExperienced
            } catch (e: Exception) {
                dateExperienced
            }
        }

    val severityColor: String
        get() = when (severity) {
            in 1..3 -> "#4CAF50" // Green
            in 4..6 -> "#FFEB3B" // Yellow
            in 7..8 -> "#FF9800" // Orange
            in 9..10 -> "#F44336" // Red
            else -> "#9E9E9E" // Gray
        }
}

data class JournalEntryResponse(
    val message: String,
    val entry: JournalEntry
)

data class Activity(
    val id: Int,
    val name: String,
    val frequency: String?,
    val intensity: String,
    val notes: String?,
    @SerializedName("created_at") val createdAt: String
)

data class ActivityResponse(
    val message: String,
    val activity: Activity
)

data class Allergy(
    val id: Int,
    @SerializedName("food_item") val foodItem: String,
    val severity: String,
    val notes: String?,
    @SerializedName("created_at") val createdAt: String
) {
    val severityColor: String
        get() = when (severity) {
            "mild" -> "#4CAF50" // Green
            "moderate" -> "#FFEB3B" // Yellow
            "severe" -> "#F44336" // Red
            else -> "#9E9E9E" // Gray
        }
}

data class AllergyResponse(
    val message: String,
    val allergy: Allergy
)

data class Recommendation(
    val id: Int,
    val title: String,
    val description: String,
    @SerializedName("recommendation_type") val recommendationType: String,
    val priority: Int
) {
    val typeColor: String
        get() = when (recommendationType) {
            "lifestyle" -> "#2196F3" // Blue
            "nutrition" -> "#4CAF50" // Green
            "sports" -> "#FF9800" // Orange
            "exercise" -> "#9C27B0" // Purple
            else -> "#9E9E9E" // Gray
        }
}

data class RecoveryPlan(
    val id: Int,
    val title: String,
    val description: String?,
    @SerializedName("plan_type") val planType: String,
    @SerializedName("ai_generated") val aiGenerated: Boolean,
    @SerializedName("created_at") val createdAt: String
) {
    val planTypeDisplay: String
        get() = when (planType) {
            "general" -> "General Recovery"
            "nutrition" -> "Nutrition"
            "sports" -> "Sports Recovery"
            else -> planType.capitalize(Locale.getDefault())
        }

    val formattedDate: String
        get() {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val outputFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
            return try {
                val date = inputFormat.parse(createdAt)
                date?.let { outputFormat.format(it) } ?: createdAt
            } catch (e: Exception) {
                createdAt
            }
        }
}

data class RecoveryPlanDetail(
    val id: Int,
    val title: String,
    val description: String?,
    @SerializedName("plan_type") val planType: String,
    @SerializedName("ai_generated") val aiGenerated: Boolean,
    @SerializedName("created_at") val createdAt: String,
    val recommendations: List<Recommendation>
)

data class RecoveryPlanResponse(
    val message: String,
    val plan: RecoveryPlanDetail
)

data class ChartDataset(
    val label: String,
    val data: List<Int>,
    val backgroundColor: String,
    val borderColor: String,
    val borderWidth: Int,
    val fill: Boolean,
    val tension: Double,
    val dates: List<String>
)

data class ChartData(
    val labels: List<String>,
    val datasets: List<ChartDataset>
)