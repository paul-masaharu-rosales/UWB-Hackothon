# MediTrack Mobile API Documentation

This document outlines the API endpoints available for the MediTrack mobile application.

## Base URL

All API endpoints are prefixed with `/api`

## Authentication

MediTrack API uses session-based authentication. Most endpoints require authentication.

### Login

- **URL**: `/api/auth/login`
- **Method**: `POST`
- **Description**: Authenticate a user and create a session
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "userpassword"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Login successful",
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "age": 30,
      "gender": "male",
      "weight": 75.5,
      "height": 180.0,
      "bmi": 23.3
    }
  }
  ```

### Register

- **URL**: `/api/auth/register`
- **Method**: `POST`
- **Description**: Create a new user account
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "userpassword",
    "first_name": "John",     // optional
    "last_name": "Doe",       // optional
    "age": 30,                // optional
    "gender": "male",         // optional
    "weight": 75.5,           // optional
    "height": 180.0           // optional
  }
  ```
- **Response**:
  ```json
  {
    "message": "Registration successful",
    "user_id": 1
  }
  ```

### Logout

- **URL**: `/api/auth/logout`
- **Method**: `POST`
- **Description**: End the user's session
- **Authentication**: Required
- **Response**:
  ```json
  {
    "message": "Logout successful"
  }
  ```

## User Profile

### Get Profile

- **URL**: `/api/user/profile`
- **Method**: `GET`
- **Description**: Get the current user's profile information
- **Authentication**: Required
- **Response**:
  ```json
  {
    "id": 1,
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "age": 30,
    "gender": "male",
    "weight": 75.5,
    "height": 180.0,
    "bmi": 23.3
  }
  ```

### Update Profile

- **URL**: `/api/user/profile`
- **Method**: `PUT`
- **Description**: Update the current user's profile
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "first_name": "John",    // optional
    "last_name": "Doe",      // optional
    "age": 30,               // optional
    "gender": "male",        // optional
    "weight": 75.5,          // optional
    "height": 180.0          // optional
  }
  ```
- **Response**:
  ```json
  {
    "message": "Profile updated successfully",
    "user": {
      "id": 1,
      "email": "user@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "age": 30,
      "gender": "male",
      "weight": 75.5,
      "height": 180.0,
      "bmi": 23.3
    }
  }
  ```

## Athletic Activities

### List Activities

- **URL**: `/api/activities`
- **Method**: `GET`
- **Description**: Get all activities for the current user
- **Authentication**: Required
- **Response**:
  ```json
  [
    {
      "id": 1,
      "name": "Running",
      "frequency": "3 times a week",
      "intensity": "high",
      "notes": "Usually 5km distance",
      "created_at": "2025-04-26 21:00:00"
    },
    {
      "id": 2,
      "name": "Swimming",
      "frequency": "Once a week",
      "intensity": "moderate",
      "notes": "30 minutes sessions",
      "created_at": "2025-04-26 21:00:00"
    }
  ]
  ```

### Add Activity

- **URL**: `/api/activities`
- **Method**: `POST`
- **Description**: Add a new athletic activity
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "name": "Running",
    "frequency": "3 times a week",
    "intensity": "high",
    "notes": "Usually 5km distance"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Activity added successfully",
    "activity": {
      "id": 1,
      "name": "Running",
      "frequency": "3 times a week",
      "intensity": "high",
      "notes": "Usually 5km distance",
      "created_at": "2025-04-26 21:00:00"
    }
  }
  ```

### Delete Activity

- **URL**: `/api/activities/:id`
- **Method**: `DELETE`
- **Description**: Delete an activity
- **Authentication**: Required
- **Path Parameters**:
  - `id`: ID of the activity to delete
- **Response**:
  ```json
  {
    "message": "Activity deleted successfully"
  }
  ```

## Food Allergies

### List Allergies

- **URL**: `/api/allergies`
- **Method**: `GET`
- **Description**: Get all food allergies for the current user
- **Authentication**: Required
- **Response**:
  ```json
  [
    {
      "id": 1,
      "food_item": "Peanuts",
      "severity": "severe",
      "notes": "Causes anaphylaxis",
      "created_at": "2025-04-26 21:00:00"
    },
    {
      "id": 2,
      "food_item": "Dairy",
      "severity": "moderate",
      "notes": "Digestive issues",
      "created_at": "2025-04-26 21:00:00"
    }
  ]
  ```

### Add Allergy

- **URL**: `/api/allergies`
- **Method**: `POST`
- **Description**: Add a new food allergy
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "food_item": "Peanuts",
    "severity": "severe",
    "notes": "Causes anaphylaxis"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Allergy added successfully",
    "allergy": {
      "id": 1,
      "food_item": "Peanuts",
      "severity": "severe",
      "notes": "Causes anaphylaxis",
      "created_at": "2025-04-26 21:00:00"
    }
  }
  ```

### Delete Allergy

- **URL**: `/api/allergies/:id`
- **Method**: `DELETE`
- **Description**: Delete a food allergy
- **Authentication**: Required
- **Path Parameters**:
  - `id`: ID of the allergy to delete
- **Response**:
  ```json
  {
    "message": "Allergy deleted successfully"
  }
  ```

## Medical Journal

### List Journal Entries

- **URL**: `/api/journal`
- **Method**: `GET`
- **Description**: Get all journal entries for the current user
- **Authentication**: Required
- **Response**:
  ```json
  [
    {
      "id": 1,
      "symptom": "Headache",
      "description": "Dull pain behind eyes",
      "severity": 6,
      "date_experienced": "2025-04-25",
      "created_at": "2025-04-26 21:00:00"
    },
    {
      "id": 2,
      "symptom": "Back pain",
      "description": "Lower back pain after sitting",
      "severity": 5,
      "date_experienced": "2025-04-26",
      "created_at": "2025-04-26 21:00:00"
    }
  ]
  ```

### Add Journal Entry

- **URL**: `/api/journal`
- **Method**: `POST`
- **Description**: Add a new journal entry
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "symptom": "Headache",
    "description": "Dull pain behind eyes",
    "severity": 6,
    "date_experienced": "2025-04-25"
  }
  ```
- **Response**:
  ```json
  {
    "message": "Journal entry added successfully",
    "entry": {
      "id": 1,
      "symptom": "Headache",
      "description": "Dull pain behind eyes",
      "severity": 6,
      "date_experienced": "2025-04-25",
      "created_at": "2025-04-26 21:00:00"
    }
  }
  ```

### Delete Journal Entry

- **URL**: `/api/journal/:id`
- **Method**: `DELETE`
- **Description**: Delete a journal entry
- **Authentication**: Required
- **Path Parameters**:
  - `id`: ID of the journal entry to delete
- **Response**:
  ```json
  {
    "message": "Journal entry deleted successfully"
  }
  ```

### Get Chart Data

- **URL**: `/api/journal/chart-data`
- **Method**: `GET`
- **Description**: Get data formatted for charting symptoms over time
- **Authentication**: Required
- **Response**:
  ```json
  {
    "labels": ["2025-04-20", "2025-04-21", "2025-04-22", "2025-04-23"],
    "datasets": [
      {
        "label": "Headache",
        "data": [7, 5, 3, 2],
        "backgroundColor": "#4e73df",
        "borderColor": "#4e73df",
        "borderWidth": 2,
        "fill": false,
        "tension": 0.3,
        "dates": ["2025-04-20", "2025-04-21", "2025-04-22", "2025-04-23"]
      },
      {
        "label": "Back pain",
        "data": [0, 4, 5, 5],
        "backgroundColor": "#1cc88a",
        "borderColor": "#1cc88a",
        "borderWidth": 2,
        "fill": false,
        "tension": 0.3,
        "dates": ["2025-04-21", "2025-04-22", "2025-04-23"]
      }
    ]
  }
  ```

## Recovery Plans

### List Recovery Plans

- **URL**: `/api/recovery-plans`
- **Method**: `GET`
- **Description**: Get recovery plans for the current user
- **Authentication**: Required
- **Query Parameters**:
  - `type`: (optional) Filter by plan type (general, nutrition, sports)
- **Response**:
  ```json
  [
    {
      "id": 1,
      "title": "Headache Recovery Plan",
      "description": "A plan to address recurring headaches",
      "plan_type": "general",
      "ai_generated": true,
      "created_at": "2025-04-26 21:00:00"
    },
    {
      "id": 2,
      "title": "Back Pain Nutrition Plan",
      "description": "Nutrition guidance for back pain management",
      "plan_type": "nutrition",
      "ai_generated": true,
      "created_at": "2025-04-26 21:00:00"
    }
  ]
  ```

### Get Recovery Plan Details

- **URL**: `/api/recovery-plans/:id`
- **Method**: `GET`
- **Description**: Get details of a specific recovery plan
- **Authentication**: Required
- **Path Parameters**:
  - `id`: ID of the recovery plan
- **Response**:
  ```json
  {
    "id": 1,
    "title": "Headache Recovery Plan",
    "description": "A plan to address recurring headaches",
    "plan_type": "general",
    "ai_generated": true,
    "created_at": "2025-04-26 21:00:00",
    "recommendations": [
      {
        "id": 1,
        "title": "Proper hydration",
        "description": "Ensure adequate water intake throughout the day.",
        "recommendation_type": "lifestyle",
        "priority": 1
      },
      {
        "id": 2,
        "title": "Sleep hygiene",
        "description": "Maintain a consistent sleep schedule and ensure 7-8 hours of quality sleep.",
        "recommendation_type": "lifestyle",
        "priority": 2
      }
    ]
  }
  ```

### Generate General Recovery Plan

- **URL**: `/api/recovery-plans/general`
- **Method**: `POST`
- **Description**: Generate a general recovery plan based on symptoms
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "symptom_ids": [1, 2, 3]
  }
  ```
- **Response**:
  ```json
  {
    "message": "Recovery plan generated successfully",
    "plan": {
      "id": 1,
      "title": "Headache and Back Pain Recovery Plan",
      "description": "A comprehensive plan to address your headaches and back pain",
      "plan_type": "general",
      "ai_generated": true,
      "created_at": "2025-04-26 21:00:00",
      "recommendations": [
        {
          "title": "Proper hydration",
          "description": "Ensure adequate water intake throughout the day.",
          "recommendation_type": "lifestyle",
          "priority": 1
        },
        {
          "title": "Sleep hygiene",
          "description": "Maintain a consistent sleep schedule and ensure 7-8 hours of quality sleep.",
          "recommendation_type": "lifestyle",
          "priority": 2
        }
      ]
    }
  }
  ```

### Generate Nutrition Plan

- **URL**: `/api/recovery-plans/nutrition`
- **Method**: `POST`
- **Description**: Generate a nutrition plan based on symptoms
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "symptom_ids": [1, 2, 3]
  }
  ```
- **Response**:
  ```json
  {
    "message": "Nutrition plan generated successfully",
    "plan": {
      "id": 2,
      "title": "Anti-Inflammatory Nutrition Plan",
      "description": "A nutrition plan focused on reducing inflammation and supporting recovery",
      "plan_type": "nutrition",
      "ai_generated": true,
      "created_at": "2025-04-26 21:00:00",
      "recommendations": [
        {
          "title": "Increase omega-3 fatty acids",
          "description": "Include fatty fish like salmon or sardines 2-3 times per week.",
          "recommendation_type": "nutrition",
          "priority": 1
        },
        {
          "title": "Hydration",
          "description": "Drink at least 8 glasses of water daily.",
          "recommendation_type": "nutrition",
          "priority": 2
        }
      ]
    }
  }
  ```

### Generate Sports Recovery Plan

- **URL**: `/api/recovery-plans/sports`
- **Method**: `POST`
- **Description**: Generate a sports-specific recovery plan
- **Authentication**: Required
- **Request Body**:
  ```json
  {
    "symptom_ids": [1, 2, 3],
    "activity_ids": [1, 2]
  }
  ```
- **Response**:
  ```json
  {
    "message": "Sports recovery plan generated successfully",
    "plan": {
      "id": 3,
      "title": "Runner's Recovery Plan",
      "description": "A specialized plan for runners experiencing back pain",
      "plan_type": "sports",
      "ai_generated": true,
      "created_at": "2025-04-26 21:00:00",
      "recommendations": [
        {
          "title": "Active recovery",
          "description": "Implement walking or swimming on rest days.",
          "recommendation_type": "sports",
          "priority": 1
        },
        {
          "title": "Strengthen core muscles",
          "description": "Add plank and glute bridge exercises to your routine.",
          "recommendation_type": "sports",
          "priority": 2
        }
      ]
    }
  }
  ```