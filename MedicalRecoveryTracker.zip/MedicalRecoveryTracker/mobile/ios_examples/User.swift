import Foundation

struct User: Codable, Identifiable {
    let id: Int
    let email: String
    let firstName: String?
    let lastName: String?
    let age: Int?
    let gender: String?
    let weight: Double?
    let height: Double?
    let bmi: Double?
    
    var fullName: String {
        if let firstName = firstName, let lastName = lastName {
            return "\(firstName) \(lastName)"
        } else if let firstName = firstName {
            return firstName
        } else if let lastName = lastName {
            return lastName
        } else {
            return email
        }
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case email
        case firstName = "first_name"
        case lastName = "last_name"
        case age
        case gender
        case weight
        case height
        case bmi
    }
}

struct JournalEntry: Codable, Identifiable {
    let id: Int
    let symptom: String
    let description: String?
    let severity: Int
    let dateExperienced: String
    let createdAt: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case symptom
        case description
        case severity
        case dateExperienced = "date_experienced"
        case createdAt = "created_at"
    }
    
    var formattedDate: String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd"
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "MMM d, yyyy"
        
        if let date = inputFormatter.date(from: dateExperienced) {
            return outputFormatter.string(from: date)
        }
        return dateExperienced
    }
    
    var severityColor: String {
        switch severity {
        case 1...3:
            return "green"
        case 4...6:
            return "yellow"
        case 7...8:
            return "orange"
        case 9...10:
            return "red"
        default:
            return "gray"
        }
    }
}

struct JournalEntryResponse: Codable {
    let message: String
    let entry: JournalEntry
}

struct Activity: Codable, Identifiable {
    let id: Int
    let name: String
    let frequency: String?
    let intensity: String
    let notes: String?
    let createdAt: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case frequency
        case intensity
        case notes
        case createdAt = "created_at"
    }
}

struct ActivityResponse: Codable {
    let message: String
    let activity: Activity
}

struct Allergy: Codable, Identifiable {
    let id: Int
    let foodItem: String
    let severity: String
    let notes: String?
    let createdAt: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case foodItem = "food_item"
        case severity
        case notes
        case createdAt = "created_at"
    }
    
    var severityColor: String {
        switch severity {
        case "mild":
            return "green"
        case "moderate":
            return "yellow"
        case "severe":
            return "red"
        default:
            return "gray"
        }
    }
}

struct AllergyResponse: Codable {
    let message: String
    let allergy: Allergy
}

struct RecoveryPlan: Codable, Identifiable {
    let id: Int
    let title: String
    let description: String?
    let planType: String
    let aiGenerated: Bool
    let createdAt: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case planType = "plan_type"
        case aiGenerated = "ai_generated"
        case createdAt = "created_at"
    }
    
    var planTypeDisplay: String {
        switch planType {
        case "general":
            return "General Recovery"
        case "nutrition":
            return "Nutrition"
        case "sports":
            return "Sports Recovery"
        default:
            return planType.capitalized
        }
    }
    
    var formattedDate: String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "MMM d, yyyy"
        
        if let date = inputFormatter.date(from: createdAt) {
            return outputFormatter.string(from: date)
        }
        return createdAt
    }
}

struct Recommendation: Codable, Identifiable {
    let id: Int
    let title: String
    let description: String
    let recommendationType: String
    let priority: Int
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case recommendationType = "recommendation_type"
        case priority
    }
    
    var typeColor: String {
        switch recommendationType {
        case "lifestyle":
            return "blue"
        case "nutrition":
            return "green"
        case "sports":
            return "orange"
        case "exercise":
            return "purple"
        default:
            return "gray"
        }
    }
}

struct RecoveryPlanDetail: Codable, Identifiable {
    let id: Int
    let title: String
    let description: String?
    let planType: String
    let aiGenerated: Bool
    let createdAt: String
    let recommendations: [Recommendation]
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case planType = "plan_type"
        case aiGenerated = "ai_generated"
        case createdAt = "created_at"
        case recommendations
    }
}

struct RecoveryPlanResponse: Codable {
    let message: String
    let plan: RecoveryPlanDetail
}

struct ChartDataset: Codable {
    let label: String
    let data: [Int]
    let backgroundColor: String
    let borderColor: String
    let borderWidth: Int
    let fill: Bool
    let tension: Double
    let dates: [String]
}

struct ChartData: Codable {
    let labels: [String]
    let datasets: [ChartDataset]
}