import SwiftUI
import Combine

class JournalViewModel: ObservableObject {
    @Published var journalEntries: [JournalEntry] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String = ""
    @Published var showingAddJournal: Bool = false
    
    private let apiService: APIService
    private var cancellables = Set<AnyCancellable>()
    
    init(apiService: APIService = APIService.shared) {
        self.apiService = apiService
        fetchJournalEntries()
    }
    
    func fetchJournalEntries() {
        isLoading = true
        errorMessage = ""
        
        apiService.getJournalEntries()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] entries in
                self?.journalEntries = entries
            }
            .store(in: &cancellables)
    }
    
    func deleteJournalEntry(id: Int) {
        isLoading = true
        
        apiService.deleteJournalEntry(id: id)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] _ in
                // Remove the deleted entry from the local array
                self?.journalEntries.removeAll { $0.id == id }
            }
            .store(in: &cancellables)
    }
    
    func addJournalEntry(symptom: String, description: String?, severity: Int, date: Date) {
        isLoading = true
        errorMessage = ""
        
        apiService.addJournalEntry(symptom: symptom, description: description, severity: severity, dateExperienced: date)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                // Add the new entry to the local array
                self?.journalEntries.append(response.entry)
                // Sort entries by date, newest first
                self?.journalEntries.sort { 
                    $0.dateExperienced > $1.dateExperienced
                }
            }
            .store(in: &cancellables)
    }
}

struct JournalListView: View {
    @StateObject private var viewModel = JournalViewModel()
    @State private var confirmingDelete: Int? = nil
    
    var body: some View {
        NavigationView {
            ZStack {
                List {
                    ForEach(viewModel.journalEntries) { entry in
                        JournalEntryRow(entry: entry)
                            .swipeActions(edge: .trailing) {
                                Button(role: .destructive) {
                                    confirmingDelete = entry.id
                                } label: {
                                    Label("Delete", systemImage: "trash")
                                }
                            }
                    }
                }
                
                if viewModel.journalEntries.isEmpty && !viewModel.isLoading {
                    VStack {
                        Image(systemName: "clipboard")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                            .padding()
                        
                        Text("No symptoms recorded yet")
                            .font(.headline)
                            .foregroundColor(.gray)
                        
                        Text("Tap the + button to start tracking your symptoms")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button("Add First Symptom") {
                            viewModel.showingAddJournal = true
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                        .padding(.top)
                    }
                    .padding()
                }
                
                if viewModel.isLoading {
                    ProgressView("Loading...")
                        .progressViewStyle(CircularProgressViewStyle())
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemBackground)))
                        .shadow(radius: 10)
                }
            }
            .navigationTitle("Symptom Journal")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        viewModel.showingAddJournal = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
                
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        viewModel.fetchJournalEntries()
                    }) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .sheet(isPresented: $viewModel.showingAddJournal) {
                AddJournalView(viewModel: viewModel)
            }
            .alert(item: Binding(
                get: { confirmingDelete.map { DeleteConfirmation(id: $0) } },
                set: { confirmingDelete = $0?.id }
            )) { item in
                Alert(
                    title: Text("Delete Entry"),
                    message: Text("Are you sure you want to delete this symptom entry? This action cannot be undone."),
                    primaryButton: .destructive(Text("Delete")) {
                        viewModel.deleteJournalEntry(id: item.id)
                        confirmingDelete = nil
                    },
                    secondaryButton: .cancel {
                        confirmingDelete = nil
                    }
                )
            }
            .alert(isPresented: Binding<Bool>(
                get: { !viewModel.errorMessage.isEmpty },
                set: { if !$0 { viewModel.errorMessage = "" } }
            )) {
                Alert(
                    title: Text("Error"),
                    message: Text(viewModel.errorMessage),
                    dismissButton: .default(Text("OK")) {
                        viewModel.errorMessage = ""
                    }
                )
            }
        }
    }
}

struct DeleteConfirmation: Identifiable {
    let id: Int
}

struct JournalEntryRow: View {
    let entry: JournalEntry
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(entry.symptom)
                    .font(.headline)
                
                Spacer()
                
                Text(entry.formattedDate)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            if let description = entry.description, !description.isEmpty {
                Text(description)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            
            HStack {
                Text("Severity:")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                SeverityView(severity: entry.severity)
            }
        }
        .padding(.vertical, 4)
    }
}

struct SeverityView: View {
    let severity: Int
    
    var color: Color {
        switch severity {
        case 1...3:
            return .green
        case 4...6:
            return .yellow
        case 7...8:
            return .orange
        case 9...10:
            return .red
        default:
            return .gray
        }
    }
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(1...10, id: \.self) { i in
                Rectangle()
                    .fill(i <= severity ? color : Color.gray.opacity(0.3))
                    .frame(height: 8)
                    .cornerRadius(4)
            }
            
            Text("\(severity)/10")
                .font(.caption)
                .foregroundColor(.gray)
                .frame(width: 40, alignment: .trailing)
        }
    }
}

struct AddJournalView: View {
    @ObservedObject var viewModel: JournalViewModel
    @Environment(\.presentationMode) private var presentationMode
    
    @State private var symptom: String = ""
    @State private var description: String = ""
    @State private var severity: Double = 5
    @State private var date: Date = Date()
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Symptom Details")) {
                    TextField("Symptom Name", text: $symptom)
                    
                    DatePicker("Date Experienced", selection: $date, displayedComponents: .date)
                }
                
                Section(header: Text("Description (Optional)")) {
                    TextEditor(text: $description)
                        .frame(minHeight: 100)
                }
                
                Section(header: Text("Severity: \(Int(severity))/10")) {
                    VStack {
                        Slider(value: $severity, in: 1...10, step: 1)
                            .accentColor(severityColor)
                        
                        HStack {
                            Text("Mild")
                                .foregroundColor(.green)
                            
                            Spacer()
                            
                            Text("Moderate")
                                .foregroundColor(.yellow)
                            
                            Spacer()
                            
                            Text("Severe")
                                .foregroundColor(.red)
                        }
                        .font(.caption)
                    }
                }
            }
            .navigationTitle("Add Symptom")
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    saveEntry()
                }
                .disabled(symptom.isEmpty)
            )
            .disabled(viewModel.isLoading)
            .overlay(
                Group {
                    if viewModel.isLoading {
                        Color.black.opacity(0.2)
                            .ignoresSafeArea()
                        
                        ProgressView("Saving...")
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemBackground)))
                            .shadow(radius: 10)
                    }
                }
            )
        }
    }
    
    private var severityColor: Color {
        switch Int(severity) {
        case 1...3:
            return .green
        case 4...6:
            return .yellow
        case 7...8:
            return .orange
        case 9...10:
            return .red
        default:
            return .gray
        }
    }
    
    private func saveEntry() {
        viewModel.addJournalEntry(
            symptom: symptom,
            description: description.isEmpty ? nil : description,
            severity: Int(severity),
            date: date
        )
        
        // Close the sheet if no error occurred
        if viewModel.errorMessage.isEmpty {
            presentationMode.wrappedValue.dismiss()
        }
    }
}