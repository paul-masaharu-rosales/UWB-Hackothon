import SwiftUI

struct GenerateRecoveryPlanView: View {
    @StateObject private var viewModel = RecoveryPlanViewModel()
    @State private var planType: PlanType = .general
    @State private var showingPlanDetail = false
    
    enum PlanType: String, CaseIterable, Identifiable {
        case general = "General Recovery"
        case nutrition = "Nutrition"
        case sports = "Sports Recovery"
        
        var id: String { self.rawValue }
        
        var description: String {
            switch self {
            case .general:
                return "A comprehensive plan to address your symptoms with lifestyle recommendations and general recovery advice."
            case .nutrition:
                return "Dietary guidance tailored to alleviate your symptoms and support recovery with nutritional recommendations."
            case .sports:
                return "Sports-specific recovery strategies for athletes, incorporating your activity profile and symptom patterns."
            }
        }
        
        var icon: String {
            switch self {
            case .general:
                return "heart.text.square"
            case .nutrition:
                return "leaf"
            case .sports:
                return "figure.run"
            }
        }
        
        var color: Color {
            switch self {
            case .general:
                return .blue
            case .nutrition:
                return .green
            case .sports:
                return .orange
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Plan Type Selection
                    planTypeSelector
                    
                    // Symptom Selection Section
                    symptomSelectionSection
                    
                    // Activity Selection Section (only for sports plan)
                    if planType == .sports {
                        activitySelectionSection
                    }
                    
                    // Generate Button
                    generateButton
                }
                .padding()
            }
            .navigationTitle("AI Recovery Plan")
            .alert(isPresented: Binding<Bool>(
                get: { !viewModel.errorMessage.isEmpty },
                set: { if !$0 { viewModel.errorMessage = "" } }
            )) {
                Alert(
                    title: Text("Error"),
                    message: Text(viewModel.errorMessage),
                    dismissButton: .default(Text("OK")) {
                        viewModel.errorMessage = ""
                    }
                )
            }
            .sheet(isPresented: $showingPlanDetail) {
                if let planDetails = viewModel.selectedPlanDetails {
                    RecoveryPlanDetailView(planDetail: planDetails)
                }
            }
            .overlay {
                if viewModel.isLoading {
                    ZStack {
                        Color.black.opacity(0.3)
                            .ignoresSafeArea()
                        
                        VStack(spacing: 20) {
                            ProgressView()
                                .scaleEffect(1.5)
                            
                            Text("Generating your personalized plan...")
                                .font(.headline)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                            
                            Text("Our AI is analyzing your symptoms and creating recommendations.")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .padding(30)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(Color(.systemGray6).opacity(0.8))
                        )
                        .shadow(radius: 20)
                    }
                }
            }
        }
    }
    
    // MARK: - Plan Type Selector
    private var planTypeSelector: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Select Plan Type")
                .font(.headline)
            
            ForEach(PlanType.allCases) { type in
                Button(action: {
                    planType = type
                }) {
                    HStack(spacing: 16) {
                        Image(systemName: type.icon)
                            .font(.title2)
                            .foregroundColor(type.color)
                            .frame(width: 40, height: 40)
                            .background(type.color.opacity(0.1))
                            .clipShape(Circle())
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(type.rawValue)
                                .font(.headline)
                            
                            Text(type.description)
                                .font(.caption)
                                .foregroundColor(.gray)
                                .lineLimit(2)
                        }
                        
                        Spacer()
                        
                        if planType == type {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(type.color)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(planType == type ? type.color : Color.gray.opacity(0.3), lineWidth: 2)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(planType == type ? type.color.opacity(0.05) : Color(.systemBackground))
                            )
                    )
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
    }
    
    // MARK: - Symptom Selection Section
    private var symptomSelectionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Select Symptoms")
                    .font(.headline)
                
                Spacer()
                
                Text("\(viewModel.selectedSymptomIds.count) selected")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            if viewModel.journalEntries.isEmpty {
                EmptyStateView(
                    systemName: "bandage",
                    title: "No Symptoms Recorded",
                    message: "You need to record symptoms in your journal before generating a recovery plan."
                )
            } else {
                ForEach(viewModel.journalEntries) { entry in
                    Button(action: {
                        viewModel.toggleSymptomSelection(id: entry.id)
                    }) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.symptom)
                                    .font(.headline)
                                
                                HStack {
                                    Text("Severity: \(entry.severity)/10")
                                        .font(.caption)
                                    
                                    Text(entry.formattedDate)
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                            }
                            
                            Spacer()
                            
                            Image(systemName: viewModel.selectedSymptomIds.contains(entry.id) ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(viewModel.selectedSymptomIds.contains(entry.id) ? .blue : .gray)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                .background(
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(viewModel.selectedSymptomIds.contains(entry.id) ? Color.blue.opacity(0.1) : Color(.systemBackground))
                                )
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }
    
    // MARK: - Activity Selection Section
    private var activitySelectionSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Select Activities")
                    .font(.headline)
                
                Spacer()
                
                Text("\(viewModel.selectedActivityIds.count) selected")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            if viewModel.activities.isEmpty {
                EmptyStateView(
                    systemName: "figure.walk",
                    title: "No Activities Recorded",
                    message: "You need to add your regular athletic activities in your profile before generating a sports recovery plan."
                )
            } else {
                ForEach(viewModel.activities) { activity in
                    Button(action: {
                        viewModel.toggleActivitySelection(id: activity.id)
                    }) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(activity.name)
                                    .font(.headline)
                                
                                HStack {
                                    Text("Intensity: \(activity.intensity.capitalized)")
                                        .font(.caption)
                                    
                                    if let frequency = activity.frequency {
                                        Text(frequency)
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                    }
                                }
                            }
                            
                            Spacer()
                            
                            Image(systemName: viewModel.selectedActivityIds.contains(activity.id) ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(viewModel.selectedActivityIds.contains(activity.id) ? .orange : .gray)
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                .background(
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(viewModel.selectedActivityIds.contains(activity.id) ? Color.orange.opacity(0.1) : Color(.systemBackground))
                                )
                        )
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }
    
    // MARK: - Generate Button
    private var generateButton: some View {
        Button(action: {
            generatePlan()
        }) {
            HStack {
                Spacer()
                
                Image(systemName: "wand.and.stars")
                    .font(.headline)
                
                Text("Generate \(planType.rawValue)")
                    .font(.headline)
                
                Spacer()
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(buttonColor)
            )
            .foregroundColor(.white)
            .padding(.vertical)
        }
        .disabled(disableGenerateButton)
    }
    
    private var buttonColor: Color {
        if disableGenerateButton {
            return Color.gray
        }
        
        return planType.color
    }
    
    private var disableGenerateButton: Bool {
        if viewModel.selectedSymptomIds.isEmpty {
            return true
        }
        
        if planType == .sports && viewModel.selectedActivityIds.isEmpty {
            return true
        }
        
        return false
    }
    
    // MARK: - Functions
    private func generatePlan() {
        switch planType {
        case .general:
            viewModel.generateGeneralPlan()
        case .nutrition:
            viewModel.generateNutritionPlan()
        case .sports:
            viewModel.generateSportsPlan()
        }
        
        showingPlanDetail = true
    }
}

struct EmptyStateView: View {
    let systemName: String
    let title: String
    let message: String
    
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: systemName)
                .font(.system(size: 50))
                .foregroundColor(.gray)
            
            Text(title)
                .font(.headline)
            
            Text(message)
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct RecoveryPlanDetailView: View {
    let planDetail: RecoveryPlanDetail
    @Environment(\.presentationMode) private var presentationMode
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Header Section
                    VStack(alignment: .leading, spacing: 8) {
                        Text(planDetail.title)
                            .font(.title)
                            .fontWeight(.bold)
                        
                        if let description = planDetail.description {
                            Text(description)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        
                        HStack {
                            Label(planDetail.planTypeDisplay, systemImage: planTypeIcon)
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(planTypeColor.opacity(0.1))
                                .foregroundColor(planTypeColor)
                                .cornerRadius(8)
                            
                            Spacer()
                            
                            Text("Created \(planDetail.formattedDate)")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.bottom)
                    
                    Divider()
                    
                    // Recommendations Section
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Recommendations")
                            .font(.headline)
                        
                        ForEach(planDetail.recommendations.sorted(by: { $0.priority < $1.priority })) { recommendation in
                            RecommendationCard(recommendation: recommendation)
                        }
                    }
                }
                .padding()
            }
            .navigationBarTitle("Recovery Plan", displayMode: .inline)
            .navigationBarItems(trailing: Button("Done") {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
    
    var planTypeIcon: String {
        switch planDetail.planType {
        case "general":
            return "heart.text.square"
        case "nutrition":
            return "leaf"
        case "sports":
            return "figure.run"
        default:
            return "list.bullet"
        }
    }
    
    var planTypeColor: Color {
        switch planDetail.planType {
        case "general":
            return .blue
        case "nutrition":
            return .green
        case "sports":
            return .orange
        default:
            return .gray
        }
    }
}

struct RecommendationCard: View {
    let recommendation: Recommendation
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("\(recommendation.priority). \(recommendation.title)")
                    .font(.headline)
                
                Spacer()
                
                Text(recommendation.recommendationType.capitalized)
                    .font(.caption)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(typeColor.opacity(0.1))
                    .foregroundColor(typeColor)
                    .cornerRadius(4)
            }
            
            Text(recommendation.description)
                .font(.body)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(.systemBackground))
                )
        )
    }
    
    var typeColor: Color {
        switch recommendation.recommendationType {
        case "lifestyle":
            return .blue
        case "nutrition":
            return .green
        case "sports":
            return .orange
        case "exercise":
            return .purple
        default:
            return .gray
        }
    }
}