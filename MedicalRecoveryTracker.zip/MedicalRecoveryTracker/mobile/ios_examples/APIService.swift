import Foundation
import Combine

enum APIError: Error {
    case invalidURL
    case invalidResponse
    case networkError(Error)
    case decodingError(Error)
    case serverError(String)
    case unauthorized
    
    var localizedDescription: String {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .invalidResponse:
            return "Invalid response from server"
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .decodingError(let error):
            return "Failed to decode response: \(error.localizedDescription)"
        case .serverError(let message):
            return "Server error: \(message)"
        case .unauthorized:
            return "Unauthorized. Please login again."
        }
    }
}

// Import for SymptomCauseAnalyzer
import SwiftUI

struct LoginResponse: Codable {
    let message: String
    let user: User
}

struct RegisterResponse: Codable {
    let message: String
    let user_id: Int
}

struct MessageResponse: Codable {
    let message: String
}

class APIService {
    static let shared = APIService()
    
    private let baseURL = "http://localhost:5000/api"
    private let session: URLSession
    private let decoder: JSONDecoder
    
    private init() {
        let configuration = URLSessionConfiguration.default
        self.session = URLSession(configuration: configuration)
        
        self.decoder = JSONDecoder()
        self.decoder.keyDecodingStrategy = .convertFromSnakeCase
    }
    
    // MARK: - Authentication
    
    func login(email: String, password: String) -> AnyPublisher<LoginResponse, APIError> {
        let endpoint = "/auth/login"
        let data = ["email": email, "password": password]
        
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func register(email: String, password: String, firstName: String? = nil, lastName: String? = nil, age: Int? = nil, gender: String? = nil, weight: Double? = nil, height: Double? = nil) -> AnyPublisher<RegisterResponse, APIError> {
        let endpoint = "/auth/register"
        
        var data: [String: Any] = ["email": email, "password": password]
        
        if let firstName = firstName { data["first_name"] = firstName }
        if let lastName = lastName { data["last_name"] = lastName }
        if let age = age { data["age"] = age }
        if let gender = gender { data["gender"] = gender }
        if let weight = weight { data["weight"] = weight }
        if let height = height { data["height"] = height }
        
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func logout() -> AnyPublisher<MessageResponse, APIError> {
        let endpoint = "/auth/logout"
        return makeRequest(endpoint: endpoint, method: "POST")
    }
    
    // MARK: - User Profile
    
    func getUserProfile() -> AnyPublisher<User, APIError> {
        let endpoint = "/user/profile"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func updateUserProfile(data: [String: Any]) -> AnyPublisher<User, APIError> {
        let endpoint = "/user/profile"
        return makeRequest(endpoint: endpoint, method: "PUT", body: data)
    }
    
    // MARK: - Journal Entries
    
    func getJournalEntries() -> AnyPublisher<[JournalEntry], APIError> {
        let endpoint = "/journal"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func addJournalEntry(symptom: String, description: String?, severity: Int, dateExperienced: Date) -> AnyPublisher<JournalEntryResponse, APIError> {
        let endpoint = "/journal"
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: dateExperienced)
        
        var data: [String: Any] = [
            "symptom": symptom,
            "severity": severity,
            "date_experienced": dateString
        ]
        
        if let description = description {
            data["description"] = description
        }
        
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func deleteJournalEntry(id: Int) -> AnyPublisher<MessageResponse, APIError> {
        let endpoint = "/journal/\(id)"
        return makeRequest(endpoint: endpoint, method: "DELETE")
    }
    
    func getJournalChartData() -> AnyPublisher<ChartData, APIError> {
        let endpoint = "/journal/chart-data"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    // MARK: - Recovery Plans
    
    func getRecoveryPlans(type: String? = nil) -> AnyPublisher<[RecoveryPlan], APIError> {
        var endpoint = "/recovery-plans"
        
        if let type = type {
            endpoint += "?type=\(type)"
        }
        
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func getRecoveryPlanDetails(id: Int) -> AnyPublisher<RecoveryPlanDetail, APIError> {
        let endpoint = "/recovery-plans/\(id)"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func generateGeneralRecoveryPlan(symptomIds: [Int]) -> AnyPublisher<RecoveryPlanResponse, APIError> {
        let endpoint = "/recovery-plans/general"
        let data = ["symptom_ids": symptomIds]
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func generateNutritionPlan(symptomIds: [Int]) -> AnyPublisher<RecoveryPlanResponse, APIError> {
        let endpoint = "/recovery-plans/nutrition"
        let data = ["symptom_ids": symptomIds]
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func generateSportsPlan(symptomIds: [Int], activityIds: [Int]) -> AnyPublisher<RecoveryPlanResponse, APIError> {
        let endpoint = "/recovery-plans/sports"
        let data = ["symptom_ids": symptomIds, "activity_ids": activityIds]
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    // MARK: - Activities
    
    func getActivities() -> AnyPublisher<[Activity], APIError> {
        let endpoint = "/activities"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func addActivity(name: String, frequency: String?, intensity: String, notes: String?) -> AnyPublisher<ActivityResponse, APIError> {
        let endpoint = "/activities"
        
        var data: [String: Any] = [
            "name": name,
            "intensity": intensity
        ]
        
        if let frequency = frequency {
            data["frequency"] = frequency
        }
        
        if let notes = notes {
            data["notes"] = notes
        }
        
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func deleteActivity(id: Int) -> AnyPublisher<MessageResponse, APIError> {
        let endpoint = "/activities/\(id)"
        return makeRequest(endpoint: endpoint, method: "DELETE")
    }
    
    // MARK: - Allergies
    
    func getAllergies() -> AnyPublisher<[Allergy], APIError> {
        let endpoint = "/allergies"
        return makeRequest(endpoint: endpoint, method: "GET")
    }
    
    func addAllergy(foodItem: String, severity: String, notes: String?) -> AnyPublisher<AllergyResponse, APIError> {
        let endpoint = "/allergies"
        
        var data: [String: Any] = [
            "food_item": foodItem,
            "severity": severity
        ]
        
        if let notes = notes {
            data["notes"] = notes
        }
        
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    func deleteAllergy(id: Int) -> AnyPublisher<MessageResponse, APIError> {
        let endpoint = "/allergies/\(id)"
        return makeRequest(endpoint: endpoint, method: "DELETE")
    }
    
    // MARK: - Symptom Analysis
    
    func analyzePossibleCauses(symptomDescription: String) -> AnyPublisher<SymptomCauseResponse, APIError> {
        let endpoint = "/symptom-analysis/causes"
        let data = ["symptom_description": symptomDescription]
        return makeRequest(endpoint: endpoint, method: "POST", body: data)
    }
    
    // MARK: - Helper Methods
    
    private func makeRequest<T: Decodable>(endpoint: String, method: String, body: [String: Any]? = nil) -> AnyPublisher<T, APIError> {
        guard let url = URL(string: baseURL + endpoint) else {
            return Fail(error: APIError.invalidURL).eraseToAnyPublisher()
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let body = body {
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
            } catch {
                return Fail(error: APIError.networkError(error)).eraseToAnyPublisher()
            }
        }
        
        return session.dataTaskPublisher(for: request)
            .mapError { APIError.networkError($0) }
            .flatMap { data, response -> AnyPublisher<T, APIError> in
                guard let httpResponse = response as? HTTPURLResponse else {
                    return Fail(error: APIError.invalidResponse).eraseToAnyPublisher()
                }
                
                if httpResponse.statusCode == 401 {
                    return Fail(error: APIError.unauthorized).eraseToAnyPublisher()
                }
                
                if !(200...299).contains(httpResponse.statusCode) {
                    // Try to parse error message from server
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                           let errorMessage = json["error"] as? String {
                            return Fail(error: APIError.serverError(errorMessage)).eraseToAnyPublisher()
                        }
                    } catch {
                        // If we can't parse the error, use status code
                        return Fail(error: APIError.serverError("Server returned status code \(httpResponse.statusCode)")).eraseToAnyPublisher()
                    }
                }
                
                return Just(data)
                    .decode(type: T.self, decoder: self.decoder)
                    .mapError { APIError.decodingError($0) }
                    .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
}