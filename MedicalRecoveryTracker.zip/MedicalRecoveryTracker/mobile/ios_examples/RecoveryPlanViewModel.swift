import Foundation
import Combine

class RecoveryPlanViewModel: ObservableObject {
    @Published var recoveryPlans: [RecoveryPlan] = []
    @Published var selectedPlanDetails: RecoveryPlanDetail? = nil
    @Published var isLoading: Bool = false
    @Published var errorMessage: String = ""
    @Published var selectedSymptomIds: [Int] = []
    @Published var selectedActivityIds: [Int] = []
    @Published var journalEntries: [JournalEntry] = []
    @Published var activities: [Activity] = []
    
    private let apiService: APIService
    private var cancellables = Set<AnyCancellable>()
    
    init(apiService: APIService = APIService.shared) {
        self.apiService = apiService
        fetchRecoveryPlans()
        fetchJournalEntries()
        fetchActivities()
    }
    
    func fetchRecoveryPlans(type: String? = nil) {
        isLoading = true
        errorMessage = ""
        
        apiService.getRecoveryPlans(type: type)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] plans in
                self?.recoveryPlans = plans.sorted(by: { $0.createdAt > $1.createdAt })
            }
            .store(in: &cancellables)
    }
    
    func fetchPlanDetails(id: Int) {
        isLoading = true
        errorMessage = ""
        
        apiService.getRecoveryPlanDetails(id: id)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] planDetail in
                self?.selectedPlanDetails = planDetail
            }
            .store(in: &cancellables)
    }
    
    func fetchJournalEntries() {
        apiService.getJournalEntries()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] entries in
                self?.journalEntries = entries
            }
            .store(in: &cancellables)
    }
    
    func fetchActivities() {
        apiService.getActivities()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] activities in
                self?.activities = activities
            }
            .store(in: &cancellables)
    }
    
    func toggleSymptomSelection(id: Int) {
        if selectedSymptomIds.contains(id) {
            selectedSymptomIds.removeAll { $0 == id }
        } else {
            selectedSymptomIds.append(id)
        }
    }
    
    func toggleActivitySelection(id: Int) {
        if selectedActivityIds.contains(id) {
            selectedActivityIds.removeAll { $0 == id }
        } else {
            selectedActivityIds.append(id)
        }
    }
    
    func generateGeneralPlan() {
        guard !selectedSymptomIds.isEmpty else {
            errorMessage = "Please select at least one symptom"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        apiService.generateGeneralRecoveryPlan(symptomIds: selectedSymptomIds)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.selectedPlanDetails = response.plan
                self?.fetchRecoveryPlans() // Refresh the list
                self?.selectedSymptomIds = [] // Clear selections
            }
            .store(in: &cancellables)
    }
    
    func generateNutritionPlan() {
        guard !selectedSymptomIds.isEmpty else {
            errorMessage = "Please select at least one symptom"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        apiService.generateNutritionPlan(symptomIds: selectedSymptomIds)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.selectedPlanDetails = response.plan
                self?.fetchRecoveryPlans() // Refresh the list
                self?.selectedSymptomIds = [] // Clear selections
            }
            .store(in: &cancellables)
    }
    
    func generateSportsPlan() {
        guard !selectedSymptomIds.isEmpty else {
            errorMessage = "Please select at least one symptom"
            return
        }
        
        guard !selectedActivityIds.isEmpty else {
            errorMessage = "Please select at least one activity"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        apiService.generateSportsPlan(symptomIds: selectedSymptomIds, activityIds: selectedActivityIds)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.selectedPlanDetails = response.plan
                self?.fetchRecoveryPlans() // Refresh the list
                self?.selectedSymptomIds = [] // Clear selections
                self?.selectedActivityIds = [] // Clear selections
            }
            .store(in: &cancellables)
    }
}