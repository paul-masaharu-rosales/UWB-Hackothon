import Foundation
import Combine

class AuthViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var isAuthenticated: Bool = false
    @Published var isLoading: Bool = false
    @Published var errorMessage: String = ""
    @Published var user: User? = nil
    
    private let apiService: APIService
    private var cancellables = Set<AnyCancellable>()
    
    init(apiService: APIService = APIService.shared) {
        self.apiService = apiService
        
        // Check if user is already authenticated
        if let savedUser = UserDefaults.standard.data(forKey: "currentUser") {
            do {
                let decoder = JSONDecoder()
                self.user = try decoder.decode(User.self, from: savedUser)
                self.isAuthenticated = true
            } catch {
                print("Failed to decode saved user: \(error)")
            }
        }
    }
    
    func login() {
        isLoading = true
        errorMessage = ""
        
        apiService.login(email: email, password: password)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.user = response.user
                self?.isAuthenticated = true
                
                // Save user data
                if let userData = try? JSONEncoder().encode(response.user) {
                    UserDefaults.standard.set(userData, forKey: "currentUser")
                }
            }
            .store(in: &cancellables)
    }
    
    func register(firstName: String, lastName: String, age: Int?, gender: String?, weight: Double?, height: Double?) {
        isLoading = true
        errorMessage = ""
        
        apiService.register(email: email, password: password, firstName: firstName, lastName: lastName, age: age, gender: gender, weight: weight, height: height)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                // After successful registration, proceed to login
                self?.login()
            }
            .store(in: &cancellables)
    }
    
    func logout() {
        isLoading = true
        
        apiService.logout()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                // Clear user data even if logout API fails
                self?.clearUserData()
            } receiveValue: { [weak self] _ in
                self?.clearUserData()
            }
            .store(in: &cancellables)
    }
    
    private func clearUserData() {
        UserDefaults.standard.removeObject(forKey: "currentUser")
        self.user = nil
        self.isAuthenticated = false
        self.email = ""
        self.password = ""
    }
}