import Foundation
import Combine

struct PossibleCause: Codable, Identifiable {
    let id: String // Using UUID string
    let cause: String
    let description: String
    let likelihood: String // "High", "Medium", "Low"
    let urgencyLevel: String // "Emergency", "Urgent", "Routine", "Self-care"
    
    enum CodingKeys: String, CodingKey {
        case id
        case cause
        case description
        case likelihood
        case urgencyLevel = "urgency_level"
    }
    
    var likelihoodColor: Color {
        switch likelihood.lowercased() {
        case "high":
            return .red
        case "medium":
            return .orange
        case "low":
            return .blue
        default:
            return .gray
        }
    }
    
    var urgencyColor: Color {
        switch urgencyLevel.lowercased() {
        case "emergency":
            return .red
        case "urgent":
            return .orange
        case "routine":
            return .blue
        case "self-care":
            return .green
        default:
            return .gray
        }
    }
}

struct SymptomCauseResponse: Codable {
    let message: String
    let possibleCauses: [PossibleCause]
    let disclaimer: String
    
    enum CodingKeys: String, CodingKey {
        case message
        case possibleCauses = "possible_causes"
        case disclaimer
    }
}

class SymptomCauseViewModel: ObservableObject {
    @Published var symptomDescription: String = ""
    @Published var possibleCauses: [PossibleCause] = []
    @Published var disclaimer: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String = ""
    
    private let apiService: APIService
    private var cancellables = Set<AnyCancellable>()
    
    init(apiService: APIService = APIService.shared) {
        self.apiService = apiService
    }
    
    func analyzePossibleCauses() {
        guard !symptomDescription.isEmpty else {
            errorMessage = "Please enter a symptom description"
            return
        }
        
        isLoading = true
        errorMessage = ""
        
        apiService.analyzePossibleCauses(symptomDescription: symptomDescription)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                self?.isLoading = false
                
                if case .failure(let error) = completion {
                    self?.errorMessage = error.localizedDescription
                }
            } receiveValue: { [weak self] response in
                self?.possibleCauses = response.possibleCauses
                self?.disclaimer = response.disclaimer
            }
            .store(in: &cancellables)
    }
}