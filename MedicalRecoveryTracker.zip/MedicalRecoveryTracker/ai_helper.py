import json
import os
import logging
from openai import OpenAI

# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

def generate_recovery_plan(user, journal_entries):
    """
    Generate a recovery plan using OpenAI API based on user's symptoms
    """
    try:
        # Prepare symptom data
        symptoms_data = []
        for entry in journal_entries:
            symptoms_data.append({
                'symptom': entry.symptom,
                'description': entry.description,
                'severity': entry.severity,
                'date': entry.date_experienced.strftime('%Y-%m-%d')
            })
        
        # Prepare user data
        user_data = {
            'age': user.age,
            'gender': user.gender,
            'weight': user.weight,
            'height': user.height
        }
        
        # Create the prompt for OpenAI
        prompt = f"""
        As a medical AI assistant, generate a recovery plan for a patient with the following symptoms:
        
        Patient Information:
        Age: {user.age if user.age else 'Not provided'}
        Gender: {user.gender if user.gender else 'Not provided'}
        Weight: {user.weight if user.weight else 'Not provided'} kg
        Height: {user.height if user.height else 'Not provided'} cm
        
        Symptoms:
        {json.dumps(symptoms_data, indent=2)}
        
        Generate a comprehensive recovery plan with actionable recommendations.
        
        Return the response in the following JSON format:
        {{
            "title": "Recovery Plan Title",
            "description": "Overall description of the plan",
            "recommendations": [
                {{
                    "title": "Recommendation Title",
                    "description": "Detailed explanation",
                    "type": "lifestyle, medication, or therapy",
                    "priority": priority level (1-3, where 1 is highest priority)
                }}
            ]
        }}
        
        Provide at least 4-5 recommendations. Focus on evidence-based approaches. Do not suggest specific medications by name.
        """
        
        # Call OpenAI API
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a medical AI assistant that provides recovery recommendations based on patient symptoms."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=1500
        )
        
        # Extract and parse the response
        result = json.loads(response.choices[0].message.content)
        return result
    
    except Exception as e:
        logging.error(f"Error generating recovery plan: {str(e)}")
        return None

def generate_nutrition_plan(user, journal_entries, allergies):
    """
    Generate a nutrition plan using OpenAI API based on user's symptoms and allergies
    """
    try:
        # Prepare symptom data
        symptoms_data = []
        for entry in journal_entries:
            symptoms_data.append({
                'symptom': entry.symptom,
                'description': entry.description,
                'severity': entry.severity,
                'date': entry.date_experienced.strftime('%Y-%m-%d')
            })
        
        # Prepare allergy data
        allergies_data = []
        for allergy in allergies:
            allergies_data.append({
                'food_item': allergy.food_item,
                'severity': allergy.severity,
                'notes': allergy.notes
            })
        
        # Prepare user data
        user_data = {
            'age': user.age,
            'gender': user.gender,
            'weight': user.weight,
            'height': user.height,
            'bmi': user.calculate_bmi()
        }
        
        # Create the prompt for OpenAI
        prompt = f"""
        As a nutrition AI assistant, generate a nutrition plan for a patient with the following symptoms and allergies:
        
        Patient Information:
        Age: {user.age if user.age else 'Not provided'}
        Gender: {user.gender if user.gender else 'Not provided'}
        Weight: {user.weight if user.weight else 'Not provided'} kg
        Height: {user.height if user.height else 'Not provided'} cm
        BMI: {user.calculate_bmi() if user.calculate_bmi() else 'Not provided'}
        
        Symptoms:
        {json.dumps(symptoms_data, indent=2)}
        
        Food Allergies:
        {json.dumps(allergies_data, indent=2) if allergies_data else "No known food allergies"}
        
        Generate a comprehensive nutrition plan with dietary recommendations that can help address these symptoms.
        
        Return the response in the following JSON format:
        {{
            "title": "Nutrition Plan Title",
            "description": "Overall description of the nutrition plan",
            "recommendations": [
                {{
                    "title": "Recommendation Title",
                    "description": "Detailed explanation including suggested foods and nutrients",
                    "type": "nutrition",
                    "priority": priority level (1-3, where 1 is highest priority)
                }}
            ]
        }}
        
        Provide at least 5-6 nutrition recommendations. Focus on evidence-based approaches. Be specific about foods to include and avoid.
        """
        
        # Call OpenAI API
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a nutrition AI assistant that provides dietary recommendations based on patient symptoms and allergies."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=1500
        )
        
        # Extract and parse the response
        result = json.loads(response.choices[0].message.content)
        return result
    
    except Exception as e:
        logging.error(f"Error generating nutrition plan: {str(e)}")
        return None

def generate_sports_recovery_plan(user, journal_entries, activities):
    """
    Generate a sports-specific recovery plan using OpenAI API based on user's symptoms and athletic activities
    """
    try:
        # Prepare symptom data
        symptoms_data = []
        for entry in journal_entries:
            symptoms_data.append({
                'symptom': entry.symptom,
                'description': entry.description,
                'severity': entry.severity,
                'date': entry.date_experienced.strftime('%Y-%m-%d')
            })
        
        # Prepare activity data
        activities_data = []
        for activity in activities:
            activities_data.append({
                'name': activity.name,
                'frequency': activity.frequency,
                'intensity': activity.intensity,
                'notes': activity.notes
            })
        
        # Prepare user data
        user_data = {
            'age': user.age,
            'gender': user.gender,
            'weight': user.weight,
            'height': user.height
        }
        
        # Create the prompt for OpenAI
        prompt = f"""
        As a sports medicine AI assistant, generate a sports recovery plan for an athlete with the following symptoms and activities:
        
        Athlete Information:
        Age: {user.age if user.age else 'Not provided'}
        Gender: {user.gender if user.gender else 'Not provided'}
        Weight: {user.weight if user.weight else 'Not provided'} kg
        Height: {user.height if user.height else 'Not provided'} cm
        
        Athletic Activities:
        {json.dumps(activities_data, indent=2)}
        
        Symptoms/Injuries:
        {json.dumps(symptoms_data, indent=2)}
        
        Generate a comprehensive sports recovery plan with actionable recommendations specifically tailored for athletes.
        
        Return the response in the following JSON format:
        {{
            "title": "Sports Recovery Plan Title",
            "description": "Overall description of the plan",
            "recommendations": [
                {{
                    "title": "Recommendation Title",
                    "description": "Detailed explanation including exercises, modifications, and recovery techniques",
                    "type": "sports",
                    "priority": priority level (1-3, where 1 is highest priority)
                }}
            ]
        }}
        
        Provide at least 5-6 sports-specific recommendations. Focus on evidence-based approaches for athletic recovery.
        Include injury prevention strategies, exercise modifications, and recovery techniques.
        """
        
        # Call OpenAI API
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a sports medicine AI assistant that provides recovery recommendations for athletes based on symptoms and activities."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            max_tokens=1500
        )
        
        # Extract and parse the response
        result = json.loads(response.choices[0].message.content)
        return result
    
    except Exception as e:
        logging.error(f"Error generating sports recovery plan: {str(e)}")
        return None
