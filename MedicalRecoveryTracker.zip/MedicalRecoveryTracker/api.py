from flask import jsonify, request, Blueprint
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime, date
from app import app, db
from models import User, MedicalJournal, AthleticActivity, FoodAllergy, RecoveryPlan, Recommendation
from werkzeug.security import check_password_hash
from ai_helper import generate_recovery_plan, generate_nutrition_plan, generate_sports_recovery_plan
from ai_helper_symptoms import analyze_possible_causes
import logging

api = Blueprint('api', __name__)

# Authentication endpoints
@api.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Missing email or password'}), 400
    
    user = User.query.filter_by(email=data.get('email')).first()
    
    if not user or not user.check_password(data.get('password')):
        return jsonify({'error': 'Invalid email or password'}), 401
    
    login_user(user)
    
    return jsonify({
        'message': 'Login successful',
        'user': {
            'id': user.id,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'age': user.age,
            'gender': user.gender,
            'weight': user.weight,
            'height': user.height,
            'bmi': user.calculate_bmi()
        }
    })

@api.route('/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Missing email or password'}), 400
    
    # Check if user already exists
    existing_user = User.query.filter_by(email=data.get('email')).first()
    if existing_user:
        return jsonify({'error': 'Email already in use'}), 409
    
    # Create new user
    user = User(email=data.get('email'))
    user.set_password(data.get('password'))
    
    # Add optional profile information if provided
    if data.get('first_name'):
        user.first_name = data.get('first_name')
    if data.get('last_name'):
        user.last_name = data.get('last_name')
    if data.get('age'):
        user.age = data.get('age')
    if data.get('gender'):
        user.gender = data.get('gender')
    if data.get('weight'):
        user.weight = data.get('weight')
    if data.get('height'):
        user.height = data.get('height')
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Registration successful',
        'user_id': user.id
    }), 201

@api.route('/auth/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({'message': 'Logout successful'})

# User profile endpoints
@api.route('/user/profile', methods=['GET'])
@login_required
def get_profile():
    return jsonify({
        'id': current_user.id,
        'email': current_user.email,
        'first_name': current_user.first_name,
        'last_name': current_user.last_name,
        'age': current_user.age,
        'gender': current_user.gender,
        'weight': current_user.weight,
        'height': current_user.height,
        'bmi': current_user.calculate_bmi()
    })

@api.route('/user/profile', methods=['PUT'])
@login_required
def update_profile():
    data = request.get_json()
    
    if data.get('first_name'):
        current_user.first_name = data.get('first_name')
    if data.get('last_name'):
        current_user.last_name = data.get('last_name')
    if data.get('age'):
        current_user.age = data.get('age')
    if data.get('gender'):
        current_user.gender = data.get('gender')
    if data.get('weight'):
        current_user.weight = data.get('weight')
    if data.get('height'):
        current_user.height = data.get('height')
    
    db.session.commit()
    
    return jsonify({
        'message': 'Profile updated successfully',
        'user': {
            'id': current_user.id,
            'email': current_user.email,
            'first_name': current_user.first_name,
            'last_name': current_user.last_name,
            'age': current_user.age,
            'gender': current_user.gender,
            'weight': current_user.weight,
            'height': current_user.height,
            'bmi': current_user.calculate_bmi()
        }
    })

# Athletic Activities endpoints
@api.route('/activities', methods=['GET'])
@login_required
def get_activities():
    activities = AthleticActivity.query.filter_by(user_id=current_user.id).all()
    return jsonify([{
        'id': activity.id,
        'name': activity.name,
        'frequency': activity.frequency,
        'intensity': activity.intensity,
        'notes': activity.notes,
        'created_at': activity.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for activity in activities])

@api.route('/activities', methods=['POST'])
@login_required
def add_activity():
    data = request.get_json()
    
    if not data or not data.get('name') or not data.get('intensity'):
        return jsonify({'error': 'Missing required fields'}), 400
    
    activity = AthleticActivity(
        user_id=current_user.id,
        name=data.get('name'),
        frequency=data.get('frequency'),
        intensity=data.get('intensity'),
        notes=data.get('notes')
    )
    
    db.session.add(activity)
    db.session.commit()
    
    return jsonify({
        'message': 'Activity added successfully',
        'activity': {
            'id': activity.id,
            'name': activity.name,
            'frequency': activity.frequency,
            'intensity': activity.intensity,
            'notes': activity.notes,
            'created_at': activity.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    }), 201

@api.route('/activities/<int:id>', methods=['DELETE'])
@login_required
def delete_activity(id):
    activity = AthleticActivity.query.get_or_404(id)
    
    if activity.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    db.session.delete(activity)
    db.session.commit()
    
    return jsonify({'message': 'Activity deleted successfully'})

# Food Allergies endpoints
@api.route('/allergies', methods=['GET'])
@login_required
def get_allergies():
    allergies = FoodAllergy.query.filter_by(user_id=current_user.id).all()
    return jsonify([{
        'id': allergy.id,
        'food_item': allergy.food_item,
        'severity': allergy.severity,
        'notes': allergy.notes,
        'created_at': allergy.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for allergy in allergies])

@api.route('/allergies', methods=['POST'])
@login_required
def add_allergy():
    data = request.get_json()
    
    if not data or not data.get('food_item') or not data.get('severity'):
        return jsonify({'error': 'Missing required fields'}), 400
    
    allergy = FoodAllergy(
        user_id=current_user.id,
        food_item=data.get('food_item'),
        severity=data.get('severity'),
        notes=data.get('notes')
    )
    
    db.session.add(allergy)
    db.session.commit()
    
    return jsonify({
        'message': 'Allergy added successfully',
        'allergy': {
            'id': allergy.id,
            'food_item': allergy.food_item,
            'severity': allergy.severity,
            'notes': allergy.notes,
            'created_at': allergy.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    }), 201

@api.route('/allergies/<int:id>', methods=['DELETE'])
@login_required
def delete_allergy(id):
    allergy = FoodAllergy.query.get_or_404(id)
    
    if allergy.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    db.session.delete(allergy)
    db.session.commit()
    
    return jsonify({'message': 'Allergy deleted successfully'})

# Medical Journal endpoints
@api.route('/journal', methods=['GET'])
@login_required
def get_journal_entries():
    entries = MedicalJournal.query.filter_by(user_id=current_user.id).order_by(MedicalJournal.date_experienced.desc()).all()
    return jsonify([{
        'id': entry.id,
        'symptom': entry.symptom,
        'description': entry.description,
        'severity': entry.severity,
        'date_experienced': entry.date_experienced.strftime('%Y-%m-%d'),
        'created_at': entry.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for entry in entries])

@api.route('/journal', methods=['POST'])
@login_required
def add_journal_entry():
    data = request.get_json()
    
    if not data or not data.get('symptom') or not data.get('severity'):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        # Handle date formatting
        if isinstance(data.get('date_experienced'), str):
            date_experienced = datetime.strptime(data.get('date_experienced'), '%Y-%m-%d').date()
        else:
            date_experienced = date.today()
    except ValueError:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD.'}), 400
    
    entry = MedicalJournal(
        user_id=current_user.id,
        symptom=data.get('symptom'),
        description=data.get('description'),
        severity=data.get('severity'),
        date_experienced=date_experienced
    )
    
    db.session.add(entry)
    db.session.commit()
    
    return jsonify({
        'message': 'Journal entry added successfully',
        'entry': {
            'id': entry.id,
            'symptom': entry.symptom,
            'description': entry.description,
            'severity': entry.severity,
            'date_experienced': entry.date_experienced.strftime('%Y-%m-%d'),
            'created_at': entry.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    }), 201

@api.route('/journal/<int:id>', methods=['DELETE'])
@login_required
def delete_journal_entry(id):
    entry = MedicalJournal.query.get_or_404(id)
    
    if entry.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    db.session.delete(entry)
    db.session.commit()
    
    return jsonify({'message': 'Journal entry deleted successfully'})

@api.route('/journal/chart-data', methods=['GET'])
@login_required
def get_journal_chart_data():
    entries = MedicalJournal.query.filter_by(user_id=current_user.id).order_by(MedicalJournal.date_experienced.asc()).all()
    
    data = {
        'labels': [],
        'datasets': []
    }
    
    # Group by symptom
    symptoms = set([entry.symptom for entry in entries])
    symptom_data = {symptom: {'dates': [], 'severities': []} for symptom in symptoms}
    
    for entry in entries:
        date_str = entry.date_experienced.strftime('%Y-%m-%d')
        symptom_data[entry.symptom]['dates'].append(date_str)
        symptom_data[entry.symptom]['severities'].append(entry.severity)
    
    # Prepare datasets 
    colors = ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b']
    color_index = 0
    
    for symptom, data_points in symptom_data.items():
        color = colors[color_index % len(colors)]
        color_index += 1
        
        dataset = {
            'label': symptom,
            'data': data_points['severities'],
            'backgroundColor': color,
            'borderColor': color,
            'borderWidth': 2,
            'fill': False,
            'tension': 0.3,
            'dates': data_points['dates']
        }
        
        data['datasets'].append(dataset)
        
        # Add dates to labels if not already there
        for date_str in data_points['dates']:
            if date_str not in data['labels']:
                data['labels'].append(date_str)
    
    # Sort labels (dates) chronologically
    data['labels'].sort()
    
    return jsonify(data)

# Recovery Plans endpoints
@api.route('/recovery-plans', methods=['GET'])
@login_required
def get_recovery_plans():
    plan_type = request.args.get('type', 'all')
    
    if plan_type == 'all':
        plans = RecoveryPlan.query.filter_by(user_id=current_user.id).order_by(RecoveryPlan.created_at.desc()).all()
    else:
        plans = RecoveryPlan.query.filter_by(user_id=current_user.id, plan_type=plan_type).order_by(RecoveryPlan.created_at.desc()).all()
    
    return jsonify([{
        'id': plan.id,
        'title': plan.title,
        'description': plan.description,
        'plan_type': plan.plan_type,
        'ai_generated': plan.ai_generated,
        'created_at': plan.created_at.strftime('%Y-%m-%d %H:%M:%S')
    } for plan in plans])

@api.route('/recovery-plans/<int:id>', methods=['GET'])
@login_required
def get_recovery_plan(id):
    plan = RecoveryPlan.query.get_or_404(id)
    
    if plan.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    recommendations = Recommendation.query.filter_by(recovery_plan_id=plan.id).order_by(Recommendation.priority).all()
    
    return jsonify({
        'id': plan.id,
        'title': plan.title,
        'description': plan.description,
        'plan_type': plan.plan_type,
        'ai_generated': plan.ai_generated,
        'created_at': plan.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        'recommendations': [{
            'id': rec.id,
            'title': rec.title,
            'description': rec.description,
            'recommendation_type': rec.recommendation_type,
            'priority': rec.priority
        } for rec in recommendations]
    })

@api.route('/recovery-plans/general', methods=['POST'])
@login_required
def create_general_recovery_plan():
    data = request.get_json()
    
    if not data or not data.get('symptom_ids'):
        return jsonify({'error': 'Missing symptom IDs'}), 400
    
    symptom_ids = data.get('symptom_ids')
    
    # Get the selected journal entries
    selected_entries = MedicalJournal.query.filter(
        MedicalJournal.id.in_(symptom_ids),
        MedicalJournal.user_id == current_user.id
    ).all()
    
    if not selected_entries:
        return jsonify({'error': 'No valid symptoms found'}), 400
    
    # Generate a recovery plan using AI
    plan_data = generate_recovery_plan(current_user, selected_entries)
    
    if not plan_data:
        return jsonify({'error': 'Failed to generate recovery plan'}), 500
    
    # Create a new recovery plan
    plan = RecoveryPlan(
        user_id=current_user.id,
        title=plan_data['title'],
        description=plan_data['description'],
        plan_type='general',
        ai_generated=True
    )
    
    db.session.add(plan)
    db.session.flush()  # Get the plan ID before committing
    
    # Add recommendations
    recommendations = []
    for rec in plan_data['recommendations']:
        recommendation = Recommendation(
            recovery_plan_id=plan.id,
            title=rec['title'],
            description=rec['description'],
            recommendation_type=rec['type'],
            priority=rec['priority']
        )
        db.session.add(recommendation)
        recommendations.append({
            'title': rec['title'],
            'description': rec['description'],
            'recommendation_type': rec['type'],
            'priority': rec['priority']
        })
    
    db.session.commit()
    
    return jsonify({
        'message': 'Recovery plan generated successfully',
        'plan': {
            'id': plan.id,
            'title': plan.title,
            'description': plan.description,
            'plan_type': plan.plan_type,
            'ai_generated': plan.ai_generated,
            'created_at': plan.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'recommendations': recommendations
        }
    }), 201

@api.route('/recovery-plans/nutrition', methods=['POST'])
@login_required
def create_nutrition_plan():
    data = request.get_json()
    
    if not data or not data.get('symptom_ids'):
        return jsonify({'error': 'Missing symptom IDs'}), 400
    
    symptom_ids = data.get('symptom_ids')
    
    # Get the selected journal entries
    selected_entries = MedicalJournal.query.filter(
        MedicalJournal.id.in_(symptom_ids),
        MedicalJournal.user_id == current_user.id
    ).all()
    
    if not selected_entries:
        return jsonify({'error': 'No valid symptoms found'}), 400
    
    # Get the user's food allergies
    allergies = FoodAllergy.query.filter_by(user_id=current_user.id).all()
    
    # Generate a nutrition plan using AI
    plan_data = generate_nutrition_plan(current_user, selected_entries, allergies)
    
    if not plan_data:
        return jsonify({'error': 'Failed to generate nutrition plan'}), 500
    
    # Create a new nutrition plan
    plan = RecoveryPlan(
        user_id=current_user.id,
        title=plan_data['title'],
        description=plan_data['description'],
        plan_type='nutrition',
        ai_generated=True
    )
    
    db.session.add(plan)
    db.session.flush()  # Get the plan ID before committing
    
    # Add recommendations
    recommendations = []
    for rec in plan_data['recommendations']:
        recommendation = Recommendation(
            recovery_plan_id=plan.id,
            title=rec['title'],
            description=rec['description'],
            recommendation_type='nutrition',
            priority=rec['priority']
        )
        db.session.add(recommendation)
        recommendations.append({
            'title': rec['title'],
            'description': rec['description'],
            'recommendation_type': 'nutrition',
            'priority': rec['priority']
        })
    
    db.session.commit()
    
    return jsonify({
        'message': 'Nutrition plan generated successfully',
        'plan': {
            'id': plan.id,
            'title': plan.title,
            'description': plan.description,
            'plan_type': plan.plan_type,
            'ai_generated': plan.ai_generated,
            'created_at': plan.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'recommendations': recommendations
        }
    }), 201

@api.route('/recovery-plans/sports', methods=['POST'])
@login_required
def create_sports_plan():
    data = request.get_json()
    
    if not data or not data.get('symptom_ids') or not data.get('activity_ids'):
        return jsonify({'error': 'Missing symptom IDs or activity IDs'}), 400
    
    symptom_ids = data.get('symptom_ids')
    activity_ids = data.get('activity_ids')
    
    # Get the selected journal entries
    selected_entries = MedicalJournal.query.filter(
        MedicalJournal.id.in_(symptom_ids),
        MedicalJournal.user_id == current_user.id
    ).all()
    
    if not selected_entries:
        return jsonify({'error': 'No valid symptoms found'}), 400
    
    # Get the selected activities
    selected_activities = AthleticActivity.query.filter(
        AthleticActivity.id.in_(activity_ids),
        AthleticActivity.user_id == current_user.id
    ).all()
    
    if not selected_activities:
        return jsonify({'error': 'No valid activities found'}), 400
    
    # Generate a sports recovery plan using AI
    plan_data = generate_sports_recovery_plan(current_user, selected_entries, selected_activities)
    
    if not plan_data:
        return jsonify({'error': 'Failed to generate sports recovery plan'}), 500
    
    # Create a new sports recovery plan
    plan = RecoveryPlan(
        user_id=current_user.id,
        title=plan_data['title'],
        description=plan_data['description'],
        plan_type='sports',
        ai_generated=True
    )
    
    db.session.add(plan)
    db.session.flush()  # Get the plan ID before committing
    
    # Add recommendations
    recommendations = []
    for rec in plan_data['recommendations']:
        recommendation = Recommendation(
            recovery_plan_id=plan.id,
            title=rec['title'],
            description=rec['description'],
            recommendation_type='sports',
            priority=rec['priority']
        )
        db.session.add(recommendation)
        recommendations.append({
            'title': rec['title'],
            'description': rec['description'],
            'recommendation_type': 'sports',
            'priority': rec['priority']
        })
    
    db.session.commit()
    
    return jsonify({
        'message': 'Sports recovery plan generated successfully',
        'plan': {
            'id': plan.id,
            'title': plan.title,
            'description': plan.description,
            'plan_type': plan.plan_type,
            'ai_generated': plan.ai_generated,
            'created_at': plan.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'recommendations': recommendations
        }
    }), 201
# Symptom Analysis endpoints
@api.route("/symptom-analysis/causes", methods=["POST"])
@login_required
def analyze_symptom_causes():
    data = request.get_json()
    
    if not data or not data.get("symptom_description"):
        return jsonify({"error": "Missing symptom description"}), 400
    
    try:
        symptom_description = data.get("symptom_description")
        
        # Call the AI helper function to analyze symptoms
        result = analyze_possible_causes(symptom_description)
        
        return jsonify(result), 200
        
    except Exception as e:
        logging.error(f"Error analyzing symptom causes: {str(e)}")
        return jsonify({"error": str(e)}), 500

